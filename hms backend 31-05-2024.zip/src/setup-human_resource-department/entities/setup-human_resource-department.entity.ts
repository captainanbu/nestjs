export class SetupHumanResourceDepartment {
    id:number;
    department_name:string;
    is_active:string;
    created_at:Date;
    hospital_department_id:number;
    Hospital_id:number;
}
