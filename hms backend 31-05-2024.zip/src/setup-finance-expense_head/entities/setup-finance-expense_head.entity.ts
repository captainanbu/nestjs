export class SetupFinanceExpenseHead {
    id:number;
    exp_category:string;
    description:string;
    is_active:string;
    is_deleted:string;
    created_at:Date;
    hospital_expense_head_id:number;
    Hospital_id:number;
}
