export class SetupHospitalChargeCharge {
    id:number;
    charge_category_id:number;
    tax_category_id:number;
    charge_unit_id:number;
    name:string;
    standard_charge:string;
    date:Date;
    description:string;
    status:string;
    created_at:Date;
    hospital_charges_id:number;
    Hospital_id:number;
}
