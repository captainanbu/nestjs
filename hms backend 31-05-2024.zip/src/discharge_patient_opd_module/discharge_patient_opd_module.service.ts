

 
import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { DynamicDatabaseService } from 'src/dynamic_db.service';
import { Connection, createConnection } from 'typeorm';
import { MysqlConnectionOptions } from 'typeorm/driver/mysql/MysqlConnectionOptions';
import { DischargePatientOpdModule } from './entities/discharge_patient_opd_module.entity';
 
 
@Injectable()
export class DischargePatientOpdModuleService {
 
  constructor(@InjectConnection() private connection: Connection ,
  @Inject(forwardRef(() => DynamicDatabaseService)) private dynamicDbService: DynamicDatabaseService
  ){}
 
 
  async create(DischargePatientOpdModule: DischargePatientOpdModule) {
    let dynamicConnection;
   console.log(DischargePatientOpdModule,"body")
try{
  switch(DischargePatientOpdModule.discharge_status){
case 1 :{
 
  const [staffId] = await this.connection.query('SELECT email FROM staff WHERE id = ?', [DischargePatientOpdModule.discharge_by]);
  if (!staffId || staffId.length === 0) {
    throw new Error(`Staff with id: ${DischargePatientOpdModule.discharge_by} not found.`);
  }
 
  const docemail = staffId.email;
 
 
 
  const caseeeid = await this.connection.query(`SELECT case_reference_id from opd_details WHERE id = ?`,[DischargePatientOpdModule.opd_details_id])
  const caseipdidd = caseeeid[0].case_reference_id;
  console.log(caseipdidd,'caseeeeeiddd');
 
 
 
  const dischargePatient = await this.connection.query( `INSERT into discharge_card (
    case_reference_id,
    opd_details_id,
    ipd_details_id,
    discharge_by,
    discharge_date,
    discharge_status,
    death_date,
    operation,
    diagnosis,
    investigations,
    treatment_home,
    note
  ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
  [
    caseipdidd,
    DischargePatientOpdModule.opd_details_id,
    DischargePatientOpdModule.ipd_details_id,
    DischargePatientOpdModule.discharge_by,
    DischargePatientOpdModule.discharge_date,
    DischargePatientOpdModule.discharge_status,
    DischargePatientOpdModule.death_date,
    DischargePatientOpdModule.operation,
    DischargePatientOpdModule.diagnosis,
    DischargePatientOpdModule.investigations,
    DischargePatientOpdModule.treatment_home,
    DischargePatientOpdModule.note
  ],
  );
 
  const discharge_patient_death_id = dischargePatient.insertId;
  console.log(discharge_patient_death_id,'dischargepatientdid')
 
 
 
 
 
  const Patientiddd = await this.connection.query(`SELECT patient_id from opd_details WHERE id = ?`,[DischargePatientOpdModule.opd_details_id])
  const patientopdid = Patientiddd[0].patient_id;
  console.log(patientopdid,'patientttiddddd');
 
 
 
  const gaurdiannn = await this.connection.query(`SELECT guardian_name from patients WHERE id = ?`,[patientopdid])
  const gaurdianname = gaurdiannn[0].guardian_name;
  console.log(gaurdianname,'gaurddiannnnidddddd');
 
 
 
  const deathReport = await this.connection.query(`INSERT into death_report (
    patient_id,
    case_reference_id,
    attachment,
    attachment_name,
    death_date,
    guardian_name,
    death_report,
    is_active
  ) VALUES (?,?,?,?,?,?,?,?)`,
  [
    patientopdid,
    caseipdidd,
    DischargePatientOpdModule.attachment,
    DischargePatientOpdModule.attachment_name,
    DischargePatientOpdModule.death_date,
    gaurdianname,
    DischargePatientOpdModule.death_report,
    DischargePatientOpdModule.is_active
  ],
  );
 
  const discharge_patient_death_report_id = deathReport.insertId;
  console.log(discharge_patient_death_report_id,'dischargepatientdid')
 
 
  // const getPatientbedhistory = await this.connection.query('SELECT id FROM patient_bed_history WHERE case_reference_id = ?', [caseipdidd]);
  // const patbedhistid = getPatientbedhistory[0].id;
  // console.log(patbedhistid,"patientbedhistoryid");
 
 
 
//   const updateDischargeIPDPatientBedHistory = await this.connection.query(`
//   UPDATE patient_bed_history
//   SET to_date = ?,
//   is_active = 'no'
//   WHERE id = ?`,
//   [DischargePatientOpdModule.discharge_date, patbedhistid]
// );
 
 
 
 
 
 
  const updateDischargeIPDPatientt = await this.connection.query(`
  UPDATE opd_details
  SET discharged = 'yes'
  WHERE id = ?`,
  [DischargePatientOpdModule.opd_details_id]
);
 
 
// const dischargebeddidd = await this.connection.query('SELECT bed FROM ipd_details WHERE id = ?', [DischargePatientOpdModule.ipd_details_id]);
// const dischargeyourBedId = dischargebeddidd[0].bed;
// console.log(dischargeyourBedId,'beddddid')
 
 
// const updateDischargeBed = await this.connection.query(
//   `UPDATE bed
//    SET is_active = 'yes'
//    WHERE id = ?`,
//   [dischargeyourBedId]
// );
 
 
 
 
 
 
 
 
 
 
 
 
 
//------------------------------------------------------------------------------//
 
 
 
 
    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
      )
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
   
    dynamicConnection  = await createConnection(dynamicConnectionOptions);
 
 
   
 
 
 
 
    const dynipddddid = await dynamicConnection.query(`SELECT id from opd_details WHERE hos_opd_id = ? and Hospital_id = ?`,[DischargePatientOpdModule.opd_details_id,DischargePatientOpdModule.Hospital_id])
    const dynipddddidd = dynipddddid[0].id;
    console.log(dynipddddidd,'dynnnipddddddddiddd');
 
 
    const dyncaseeeid = await dynamicConnection.query(`SELECT case_reference_id from opd_details WHERE id = ?`,[dynipddddidd])
  const dyncaseippdidd = dyncaseeeid[0].case_reference_id;
  console.log(dyncaseippdidd,'dynnncaseeeeeeiddd');
 
 
  const dynamicUpdateStaff = await dynamicConnection.query('SELECT id FROM staff WHERE email = ?', [docemail]);
 
console.log(dynamicUpdateStaff[0].id,"1234567890-");
 
const dynamicUPTDStaffId = dynamicUpdateStaff[0].id;
 
 
 
 
 
 
  const dyndischargePatient = await dynamicConnection.query( `INSERT into discharge_card (
    case_reference_id,
    opd_details_id,
    ipd_details_id,
    discharge_by,
    discharge_date,
    discharge_status,
    death_date,
    operation,
    diagnosis,
    investigations,
    treatment_home,
    note,
    Hospital_id,
    hospital_discharge_card_id
  ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  [
    dyncaseippdidd,
    dynipddddidd,
    DischargePatientOpdModule.ipd_details_id,
    dynamicUPTDStaffId,
    DischargePatientOpdModule.discharge_date,
    DischargePatientOpdModule.discharge_status,
    DischargePatientOpdModule.death_date,
    DischargePatientOpdModule.operation,
    DischargePatientOpdModule.diagnosis,
    DischargePatientOpdModule.investigations,
    DischargePatientOpdModule.treatment_home,
    DischargePatientOpdModule.note,
    DischargePatientOpdModule.Hospital_id,
    discharge_patient_death_id
  ],
  );
 
  const dyn_discharge_patient_death_id = dyndischargePatient.insertId;
  console.log(dyn_discharge_patient_death_id,'dyndischargepatientdid')
 
 
 
 
 
  const dynPatientiddd = await dynamicConnection.query(`SELECT patient_id from opd_details WHERE id = ?`,[dynipddddidd])
  const dynpatientipdidd = dynPatientiddd[0].patient_id;
  console.log(dynpatientipdidd,'dynnnnpatientttiddddd');
 
 
 
 
  const dyngaurdiannn = await dynamicConnection.query(`SELECT guardian_name from patients WHERE id = ?`,[dynpatientipdidd])
  const dyngaurdianname = dyngaurdiannn[0].guardian_name;
  console.log(dyngaurdianname,'dynnngaurddiannnnidddddd');
 
 
 
 
 
  const dyndeathReport = await dynamicConnection.query(`INSERT into death_report (
    patient_id,
    case_reference_id,
    attachment,
    attachment_name,
    death_date,
    guardian_name,
    death_report,
    is_active,
    Hospital_id,
    hospital_death_report_id
  ) VALUES (?,?,?,?,?,?,?,?,?,?)`,
  [
    dynpatientipdidd,
    dyncaseippdidd,
    DischargePatientOpdModule.attachment,
    DischargePatientOpdModule.attachment_name,
    DischargePatientOpdModule.death_date,
    dyngaurdianname,
    DischargePatientOpdModule.death_report,
    DischargePatientOpdModule.is_active,
    DischargePatientOpdModule.Hospital_id,
    discharge_patient_death_report_id
  ],
  );
 
  const Dyndischarge_patient_death_report_id = dyndeathReport.insertId;
  console.log(Dyndischarge_patient_death_report_id,'dynnnnnnnnndischargepatientdid')
 
 
 
 
 
  // const getdynPatientbedhistory = await dynamicConnection.query('SELECT id FROM patient_bed_history WHERE hospital_patient_bed_history_id = ? and Hospital_id = ?', [patbedhistid,DischargePatientOpdModule.Hospital_id]);
  // const dynnpatbedhistid = getdynPatientbedhistory[0].id;
  // console.log(dynnpatbedhistid,"dynnpatbedhistiddddd");
 
 
 
//   const updateDynDischargeIPDPatientBedHistory = await dynamicConnection.query(`
//   UPDATE patient_bed_history
//   SET to_date = ?,
//   is_active = 'no'
//   WHERE id = ?`,
//   [DischargePatientOpdModule.discharge_date, dynnpatbedhistid]
// );
 
 
// const getdynipddetidd = await dynamicConnection.query('SELECT id FROM ipd_details WHERE case_reference_id = ? and hospital_id = ?', [dyncaseippdidd,DischargePatientOpdModule.Hospital_id]);
//   const dyndischipdidd = getdynipddetidd[0].id;
//   console.log(dyndischipdidd,"dyndischargepatientipddid");
 
 
 
  const updateDynDischargeIPDPatientt = await dynamicConnection.query(`
  UPDATE opd_details
  SET discharged = 'yes'
  WHERE id = ?`,
  [dynipddddidd]
);
 
 
// const dyndischargebeddidd = await dynamicConnection.query('SELECT bed FROM ipd_details WHERE id = ?', [dynipddddidd]);
// const dyndischargeyourBedId = dyndischargebeddidd[0].bed;
// console.log(dyndischargeyourBedId,'dyndischargeyourBedIddddd')
 
 
// const dynnnupdateDischargeBed = await dynamicConnection.query(
//   `UPDATE bed
//    SET is_active = 'yes'
//    WHERE id = ?`,
//   [dyndischargeyourBedId]
// );
 
 
 
 
 
await dynamicConnection.close();
return  [{"data ":{
  status:"success",
  "messege":"discharge patient details added successfully ",
  "Discharge_patient_details":await this.connection.query('SELECT * FROM discharge_card WHERE id = ?', [discharge_patient_death_id])
  }}];
 
 
 
 
}
case 2 :{
 
 
 
  const [staffId] = await this.connection.query('SELECT email FROM staff WHERE id = ?', [DischargePatientOpdModule.discharge_by]);
  if (!staffId || staffId.length === 0) {
    throw new Error(`Staff with id: ${DischargePatientOpdModule.discharge_by} not found.`);
  }
 
  const docemail = staffId.email;
 
 
 
  const caseeeid = await this.connection.query(`SELECT case_reference_id from ipd_details WHERE id = ?`,[DischargePatientOpdModule.ipd_details_id])
  const caseipdidd = caseeeid[0].case_reference_id;
  console.log(caseipdidd,'caseeeeeiddd');
 
 
 
  const dischargePatient = await this.connection.query( `INSERT into discharge_card (
    case_reference_id,
    opd_details_id,
    ipd_details_id,
    discharge_by,
    discharge_date,
    discharge_status,
    refer_date,
    refer_to_hospital,
    reason_for_referral,
    operation,
    diagnosis,
    investigations,
    treatment_home,
    note
  ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  [
    caseipdidd,
    DischargePatientOpdModule.opd_details_id,
    DischargePatientOpdModule.ipd_details_id,
    DischargePatientOpdModule.discharge_by,
    DischargePatientOpdModule.discharge_date,
    DischargePatientOpdModule.discharge_status,
DischargePatientOpdModule.refer_date,
DischargePatientOpdModule.refer_to_hospital,
DischargePatientOpdModule.reason_for_referral,
    DischargePatientOpdModule.operation,
    DischargePatientOpdModule.diagnosis,
    DischargePatientOpdModule.investigations,
    DischargePatientOpdModule.treatment_home,
    DischargePatientOpdModule.note
  ],
  );
 
  const discharge_patient_death_id = dischargePatient.insertId;
  console.log(discharge_patient_death_id,'dischargepatientdid')
 
 
 
 
 
  const Patientiddd = await this.connection.query(`SELECT patient_id from ipd_details WHERE id = ?`,[DischargePatientOpdModule.ipd_details_id])
  const patientipdidd = Patientiddd[0].patient_id;
  console.log(patientipdidd,'patientttiddddd');
 
 
 
  const gaurdiannn = await this.connection.query(`SELECT guardian_name from patients WHERE id = ?`,[patientipdidd])
  const gaurdianname = gaurdiannn[0].guardian_name;
  console.log(gaurdianname,'gaurddiannnnidddddd');
 
 
 
 
 
  const getPatientbedhistory = await this.connection.query('SELECT id FROM patient_bed_history WHERE case_reference_id = ?', [caseipdidd]);
  const patbedhistid = getPatientbedhistory[0].id;
  console.log(patbedhistid,"patientbedhistoryid");
 
 
 
  const updateDischargeIPDPatientBedHistory = await this.connection.query(`
  UPDATE patient_bed_history
  SET to_date = ?,
  is_active = 'no'
  WHERE id = ?`,
  [DischargePatientOpdModule.discharge_date, patbedhistid]
);
 
 
 
 
 
 
  const updateDischargeIPDPatientt = await this.connection.query(`
  UPDATE ipd_details
  SET discharged = 'yes'
  WHERE id = ?`,
  [DischargePatientOpdModule.ipd_details_id]
);
 
 
const dischargebeddidd = await this.connection.query('SELECT bed FROM ipd_details WHERE id = ?', [DischargePatientOpdModule.ipd_details_id]);
const dischargeyourBedId = dischargebeddidd[0].bed;
console.log(dischargeyourBedId,'beddddid')
 
 
const updateDischargeBed = await this.connection.query(
  `UPDATE bed
   SET is_active = 'yes'
   WHERE id = ?`,
  [dischargeyourBedId]
);
 
 
 
 
 
 
 
 
 
 
 
 
 
//------------------------------------------------------------------------------//
 
 
 
 
    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
      )
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
   
    dynamicConnection  = await createConnection(dynamicConnectionOptions);
 
 
   
 
 
 
 
    const dynipddddid = await dynamicConnection.query(`SELECT id from ipd_details WHERE hospital_ipd_details_id = ? and hospital_id = ?`,[DischargePatientOpdModule.ipd_details_id,DischargePatientOpdModule.Hospital_id])
    const dynipddddidd = dynipddddid[0].id;
    console.log(dynipddddidd,'dynnnipddddddddiddd');
 
 
    const dyncaseeeid = await dynamicConnection.query(`SELECT case_reference_id from ipd_details WHERE id = ?`,[dynipddddidd])
  const dyncaseippdidd = dyncaseeeid[0].case_reference_id;
  console.log(dyncaseippdidd,'dynnncaseeeeeeiddd');
 
 
  const dynamicUpdateStaff = await dynamicConnection.query('SELECT id FROM staff WHERE email = ?', [docemail]);
 
console.log(dynamicUpdateStaff[0].id,"1234567890-");
 
const dynamicUPTDStaffId = dynamicUpdateStaff[0].id;
 
 
 
 
 
 
  const dyndischargePatient = await dynamicConnection.query( `INSERT into discharge_card (
    case_reference_id,
    opd_details_id,
    ipd_details_id,
    discharge_by,
    discharge_date,
    discharge_status,
    refer_date,
    refer_to_hospital,
    reason_for_referral,
    operation,
    diagnosis,
    investigations,
    treatment_home,
    note,
    Hospital_id,
    hospital_discharge_card_id
  ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  [
    dyncaseippdidd,
    DischargePatientOpdModule.opd_details_id,
    dynipddddidd,
    dynamicUPTDStaffId,
    DischargePatientOpdModule.discharge_date,
    DischargePatientOpdModule.discharge_status,
    DischargePatientOpdModule.refer_date,
    DischargePatientOpdModule.refer_to_hospital,
    DischargePatientOpdModule.reason_for_referral,
    DischargePatientOpdModule.operation,
    DischargePatientOpdModule.diagnosis,
    DischargePatientOpdModule.investigations,
    DischargePatientOpdModule.treatment_home,
    DischargePatientOpdModule.note,
    DischargePatientOpdModule.Hospital_id,
    discharge_patient_death_id
  ],
  );
 
  const dyn_discharge_patient_death_id = dyndischargePatient.insertId;
  console.log(dyn_discharge_patient_death_id,'dyndischargepatientdid')
 
 
 
 
 
  const dynPatientiddd = await dynamicConnection.query(`SELECT patient_id from ipd_details WHERE id = ?`,[dynipddddidd])
  const dynpatientipdidd = dynPatientiddd[0].patient_id;
  console.log(dynpatientipdidd,'dynnnnpatientttiddddd');
 
 
 
 
  const dyngaurdiannn = await dynamicConnection.query(`SELECT guardian_name from patients WHERE id = ?`,[dynpatientipdidd])
  const dyngaurdianname = dyngaurdiannn[0].guardian_name;
  console.log(dyngaurdianname,'dynnngaurddiannnnidddddd');
 
 
 
 
 
 
 
 
  const getdynPatientbedhistory = await dynamicConnection.query('SELECT id FROM patient_bed_history WHERE hospital_patient_bed_history_id = ? and Hospital_id = ?', [patbedhistid,DischargePatientOpdModule.Hospital_id]);
  const dynnpatbedhistid = getdynPatientbedhistory[0].id;
  console.log(dynnpatbedhistid,"dynnpatbedhistiddddd");
 
 
 
  const updateDynDischargeIPDPatientBedHistory = await dynamicConnection.query(`
  UPDATE patient_bed_history
  SET to_date = ?,
  is_active = 'no'
  WHERE id = ?`,
  [DischargePatientOpdModule.discharge_date, dynnpatbedhistid]
);
 
 
// const getdynipddetidd = await dynamicConnection.query('SELECT id FROM ipd_details WHERE case_reference_id = ? and hospital_id = ?', [dyncaseippdidd,DischargePatientOpdModule.Hospital_id]);
//   const dyndischipdidd = getdynipddetidd[0].id;
//   console.log(dyndischipdidd,"dyndischargepatientipddid");
 
 
 
  const updateDynDischargeIPDPatientt = await dynamicConnection.query(`
  UPDATE ipd_details
  SET discharged = 'yes'
  WHERE id = ?`,
  [dynipddddidd]
);
 
 
const dyndischargebeddidd = await dynamicConnection.query('SELECT bed FROM ipd_details WHERE id = ?', [dynipddddidd]);
const dyndischargeyourBedId = dyndischargebeddidd[0].bed;
console.log(dyndischargeyourBedId,'dyndischargeyourBedIddddd')
 
 
const dynnnupdateDischargeBed = await dynamicConnection.query(
  `UPDATE bed
   SET is_active = 'yes'
   WHERE id = ?`,
  [dyndischargeyourBedId]
);
 
 
 
 
 
await dynamicConnection.close();
return  [{"data ":{
  status:"success",
  "messege":"discharge patient details added successfully ",
  "Discharge_patient_details":await this.connection.query('SELECT * FROM discharge_card WHERE id = ?', [discharge_patient_death_id])
  }}];
 
 
 
 
}
case 3:{
 
 
 
 
  const [staffId] = await this.connection.query('SELECT email FROM staff WHERE id = ?', [DischargePatientOpdModule.discharge_by]);
  if (!staffId || staffId.length === 0) {
    throw new Error(`Staff with id: ${DischargePatientOpdModule.discharge_by} not found.`);
  }
 
  const docemail = staffId.email;
 
 
 
  const caseeeid = await this.connection.query(`SELECT case_reference_id from ipd_details WHERE id = ?`,[DischargePatientOpdModule.ipd_details_id])
  const caseipdidd = caseeeid[0].case_reference_id;
  console.log(caseipdidd,'caseeeeeiddd');
 
 
 
  const dischargePatient = await this.connection.query( `INSERT into discharge_card (
    case_reference_id,
    opd_details_id,
    ipd_details_id,
    discharge_by,
    discharge_date,
    discharge_status,
   
    operation,
    diagnosis,
    investigations,
    treatment_home,
    note
  ) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
  [
    caseipdidd,
    DischargePatientOpdModule.opd_details_id,
    DischargePatientOpdModule.ipd_details_id,
    DischargePatientOpdModule.discharge_by,
    DischargePatientOpdModule.discharge_date,
    DischargePatientOpdModule.discharge_status,
    DischargePatientOpdModule.operation,
    DischargePatientOpdModule.diagnosis,
    DischargePatientOpdModule.investigations,
    DischargePatientOpdModule.treatment_home,
    DischargePatientOpdModule.note
  ],
  );
 
  const discharge_patient_death_id = dischargePatient.insertId;
  console.log(discharge_patient_death_id,'dischargepatientdid')
 
 
 
 
 
  const Patientiddd = await this.connection.query(`SELECT patient_id from ipd_details WHERE id = ?`,[DischargePatientOpdModule.ipd_details_id])
  const patientipdidd = Patientiddd[0].patient_id;
  console.log(patientipdidd,'patientttiddddd');
 
 
 
  const gaurdiannn = await this.connection.query(`SELECT guardian_name from patients WHERE id = ?`,[patientipdidd])
  const gaurdianname = gaurdiannn[0].guardian_name;
  console.log(gaurdianname,'gaurddiannnnidddddd');
 
 
 
 
 
  const getPatientbedhistory = await this.connection.query('SELECT id FROM patient_bed_history WHERE case_reference_id = ?', [caseipdidd]);
  const patbedhistid = getPatientbedhistory[0].id;
  console.log(patbedhistid,"patientbedhistoryid");
 
 
 
  const updateDischargeIPDPatientBedHistory = await this.connection.query(`
  UPDATE patient_bed_history
  SET to_date = ?,
  is_active = 'no'
  WHERE id = ?`,
  [DischargePatientOpdModule.discharge_date, patbedhistid]
);
 
 
 
 
 
 
  const updateDischargeIPDPatientt = await this.connection.query(`
  UPDATE ipd_details
  SET discharged = 'yes'
  WHERE id = ?`,
  [DischargePatientOpdModule.ipd_details_id]
);
 
 
const dischargebeddidd = await this.connection.query('SELECT bed FROM ipd_details WHERE id = ?', [DischargePatientOpdModule.ipd_details_id]);
const dischargeyourBedId = dischargebeddidd[0].bed;
console.log(dischargeyourBedId,'beddddid')
 
 
const updateDischargeBed = await this.connection.query(
  `UPDATE bed
   SET is_active = 'yes'
   WHERE id = ?`,
  [dischargeyourBedId]
);
 
 
 
 
 
 
 
 
 
 
 
 
 
//------------------------------------------------------------------------------//
 
 
 
 
 
    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
      )
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
   
    dynamicConnection  = await createConnection(dynamicConnectionOptions);
 
 
   
 
 
 
 
    const dynipddddid = await dynamicConnection.query(`SELECT id from ipd_details WHERE hospital_ipd_details_id = ? and hospital_id = ?`,[DischargePatientOpdModule.ipd_details_id,DischargePatientOpdModule.Hospital_id])
    const dynipddddidd = dynipddddid[0].id;
    console.log(dynipddddidd,'dynnnipddddddddiddd');
 
 
    const dyncaseeeid = await dynamicConnection.query(`SELECT case_reference_id from ipd_details WHERE id = ?`,[dynipddddidd])
  const dyncaseippdidd = dyncaseeeid[0].case_reference_id;
  console.log(dyncaseippdidd,'dynnncaseeeeeeiddd');
 
 
  const dynamicUpdateStaff = await dynamicConnection.query('SELECT id FROM staff WHERE email = ?', [docemail]);
 
console.log(dynamicUpdateStaff[0].id,"1234567890-");
 
const dynamicUPTDStaffId = dynamicUpdateStaff[0].id;
 
 
 
 
 
 
  const dyndischargePatient = await dynamicConnection.query( `INSERT into discharge_card (
    case_reference_id,
    opd_details_id,
    ipd_details_id,
    discharge_by,
    discharge_date,
    discharge_status,
    operation,
    diagnosis,
    investigations,
    treatment_home,
    note,
    Hospital_id,
    hospital_discharge_card_id
  ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  [
    dyncaseippdidd,
    DischargePatientOpdModule.opd_details_id,
    dynipddddidd,
    dynamicUPTDStaffId,
    DischargePatientOpdModule.discharge_date,
    DischargePatientOpdModule.discharge_status,
    DischargePatientOpdModule.operation,
    DischargePatientOpdModule.diagnosis,
    DischargePatientOpdModule.investigations,
    DischargePatientOpdModule.treatment_home,
    DischargePatientOpdModule.note,
    DischargePatientOpdModule.Hospital_id,
    discharge_patient_death_id
  ],
  );
 
  const dyn_discharge_patient_death_id = dyndischargePatient.insertId;
  console.log(dyn_discharge_patient_death_id,'dyndischargepatientdid')
 
 
 
 
 
  const dynPatientiddd = await dynamicConnection.query(`SELECT patient_id from ipd_details WHERE id = ?`,[dynipddddidd])
  const dynpatientipdidd = dynPatientiddd[0].patient_id;
  console.log(dynpatientipdidd,'dynnnnpatientttiddddd');
 
 
 
 
  const dyngaurdiannn = await dynamicConnection.query(`SELECT guardian_name from patients WHERE id = ?`,[dynpatientipdidd])
  const dyngaurdianname = dyngaurdiannn[0].guardian_name;
  console.log(dyngaurdianname,'dynnngaurddiannnnidddddd');
 
 
 
 
 
 
 
 
  const getdynPatientbedhistory = await dynamicConnection.query('SELECT id FROM patient_bed_history WHERE hospital_patient_bed_history_id = ? and Hospital_id = ?', [patbedhistid,DischargePatientOpdModule.Hospital_id]);
  const dynnpatbedhistid = getdynPatientbedhistory[0].id;
  console.log(dynnpatbedhistid,"dynnpatbedhistiddddd");
 
 
 
  const updateDynDischargeIPDPatientBedHistory = await dynamicConnection.query(`
  UPDATE patient_bed_history
  SET to_date = ?,
  is_active = 'no'
  WHERE id = ?`,
  [DischargePatientOpdModule.discharge_date, dynnpatbedhistid]
);
 
 
// const getdynipddetidd = await dynamicConnection.query('SELECT id FROM ipd_details WHERE case_reference_id = ? and hospital_id = ?', [dyncaseippdidd,DischargePatientOpdModule.Hospital_id]);
//   const dyndischipdidd = getdynipddetidd[0].id;
//   console.log(dyndischipdidd,"dyndischargepatientipddid");
 
 
 
  const updateDynDischargeIPDPatientt = await dynamicConnection.query(`
  UPDATE ipd_details
  SET discharged = 'yes'
  WHERE id = ?`,
  [dynipddddidd]
);
 
 
const dyndischargebeddidd = await dynamicConnection.query('SELECT bed FROM ipd_details WHERE id = ?', [dynipddddidd]);
const dyndischargeyourBedId = dyndischargebeddidd[0].bed;
console.log(dyndischargeyourBedId,'dyndischargeyourBedIddddd')
 
 
const dynnnupdateDischargeBed = await dynamicConnection.query(
  `UPDATE bed
   SET is_active = 'yes'
   WHERE id = ?`,
  [dyndischargeyourBedId]
);
 
 
 
 
 
await dynamicConnection.close();
return  [{"data ":{
  status:"success",
  "messege":"discharge patient details added successfully ",
  "Discharge_patient_details":await this.connection.query('SELECT * FROM discharge_card WHERE id = ?', [discharge_patient_death_id])
  }}];
 
 
 
 
 
}
  }
}catch(error){
  if(dynamicConnection){
    dynamicConnection.close();
  }
  console.error('Error inserting data:', error);
}
 
  }
 
 
 
 
 
 
 async findAll(): Promise<DischargePatientOpdModule[]>  {
    const getDischargeIpdDetails = await this.connection.query(`SELECT patients.patient_name AS PatientName,patients.id AS PatientID,ipd_details.case_reference_id AS Case_ID,
    patients.gender AS Gender,patients.mobileno AS Phone,
    CONCAT(staff.name, ' ', staff.surname,"(",staff.employee_id,")") AS Consultant,
    ipd_details.date AS AdmissionDate,discharge_card.discharge_date AS DischargedDate
    FROM ipd_details
    LEFT JOIN patients ON ipd_details.patient_id = patients.id
    LEFT JOIN staff ON ipd_details.cons_doctor = staff.id
    LEFT JOIN case_references ON ipd_details.case_reference_id = case_references.id
    LEFT JOIN discharge_card ON discharge_card.ipd_details_id = ipd_details.id
    WHERE
    ipd_details.discharged = 'yes'`);
    return getDischargeIpdDetails;
  }
 
 
 
 
 
  async update(id: number, DischargePatientOpdModule: DischargePatientOpdModule) {
 
    let dynamicConnection;
 
    try{
      switch(DischargePatientOpdModule.discharge_status){
    case 1 :{
 
      const uptdiscardid = await this.connection.query(`SELECT id from discharge_card WHERE opd_details_id = ?`,[id])
      const UPDDiscardidd = uptdiscardid[0].id;
      console.log(UPDDiscardidd,'UPDDischargeCardiddd');
 
 
   
   
   
      const UpdatedischargePatient = await this.connection.query(`UPDATE discharge_card SET
        discharge_date=?,
        discharge_status=?,
        death_date=?,
        operation=?,
        diagnosis=?,
        investigations=?,
        treatment_home=?,
        note=?
        WHERE id = ?`
      ,
      [
        DischargePatientOpdModule.discharge_date,
        DischargePatientOpdModule.discharge_status,
        DischargePatientOpdModule.death_date,
        DischargePatientOpdModule.operation,
        DischargePatientOpdModule.diagnosis,
        DischargePatientOpdModule.investigations,
        DischargePatientOpdModule.treatment_home,
        DischargePatientOpdModule.note,
        UPDDiscardidd
      ],
      )
 
 
      const caseeeid = await this.connection.query(`SELECT case_reference_id from opd_details WHERE id = ?`,[id])
  const caseipdidd = caseeeid[0].case_reference_id;
  console.log(caseipdidd,'caseeeeeiddd');
 
      const uptdeathhhid = await this.connection.query(`SELECT id from death_report WHERE case_reference_id = ?`,[caseipdidd])
      const UPtdeathidd = uptdeathhhid[0].id;
      console.log(UPtdeathidd,'UPtdeathidddddd');
 
 
      const UptdeathReport = await this.connection.query(`UPDATE death_report SET
        attachment=?,
        attachment_name=?,
        death_date=?,
        guardian_name=?,
        death_report=?
        WHERE id = ?`,
      [
        DischargePatientOpdModule.attachment,
        DischargePatientOpdModule.attachment_name,
        DischargePatientOpdModule.death_date,
        DischargePatientOpdModule.guardian_name,
        DischargePatientOpdModule.death_report,
        UPtdeathidd
      ],
      )
 
      const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
        process.env.ADMIN_IP,
        process.env.ADMIN_DB_NAME,
        process.env.ADMIN_DB_PASSWORD,
        process.env.ADMIN_DB_USER_NAME
        )
      const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     
      dynamicConnection  = await createConnection(dynamicConnectionOptions);
 
 
      const uptdynipddid = await dynamicConnection.query(`SELECT id from opd_details WHERE hos_opd_id = ? and Hospital_id = ?`,[id,DischargePatientOpdModule.Hospital_id])
      const UPDDynipdidd = uptdynipddid[0].id;
      console.log(UPDDynipdidd,'Dynipdidd');
 
 
 
      const uptdyndiscardid = await dynamicConnection.query(`SELECT id from discharge_card WHERE opd_details_id = ?`,[UPDDynipdidd])
      const UPDDynDiscardidd = uptdyndiscardid[0].id;
      console.log(UPDDynDiscardidd,'UPDdynDischargeCardiddd');
      console.log("sssss");
     
 
 
   
   
   
      const UpdateDyndischargePatient = await dynamicConnection.query(`UPDATE discharge_card SET
        discharge_date=?,
        discharge_status=?,
        death_date=?,
        operation=?,
        diagnosis=?,
        investigations=?,
        treatment_home=?,
        note=?
        WHERE id = ?`,
      [
        DischargePatientOpdModule.discharge_date,
        DischargePatientOpdModule.discharge_status,
        DischargePatientOpdModule.death_date,
        DischargePatientOpdModule.operation,
        DischargePatientOpdModule.diagnosis,
        DischargePatientOpdModule.investigations,
        DischargePatientOpdModule.treatment_home,
        DischargePatientOpdModule.note,
        UPDDynDiscardidd
      ],
      )
 
 
const dyncaseeeid = await dynamicConnection.query(`SELECT case_reference_id from opd_details WHERE id = ?`,[UPDDynipdidd])
  const dynncaseipdidd = dyncaseeeid[0].case_reference_id;
  console.log(dynncaseipdidd,'dynnncaseeeeeiddd');
 
      const uptDyndeathhhid = await dynamicConnection.query(`SELECT id from death_report WHERE case_reference_id = ?`,[dynncaseipdidd])
      const UPtDyndeathidd = uptDyndeathhhid[0].id;
      console.log(UPtDyndeathidd,'dynnnUPtdeathidddddd');
 
 
      const UptDynamicdeathReport = await dynamicConnection.query(`UPDATE death_report SET
        attachment=?,
        attachment_name=?,
        death_date=?,
        guardian_name=?,
        death_report=?
        WHERE id = ?`,
      [
        DischargePatientOpdModule.attachment,
        DischargePatientOpdModule.attachment_name,
        DischargePatientOpdModule.death_date,
        DischargePatientOpdModule.guardian_name,
        DischargePatientOpdModule.death_report,
        UPtDyndeathidd
      ],
      )
 
      await dynamicConnection.close();
      return  [{"data ":{
      status:"success",
     "messege":"discharged patient details updated successfully ",
     "Discharge_patient_details":await this.connection.query('SELECT * FROM discharge_card WHERE id = ?', [UPDDiscardidd])
  }}];
 
 
   
    }
 
    case 2 :{
 
 
      const uptdiscardid = await this.connection.query(`SELECT id from discharge_card WHERE opd_details_id = ?`,[id])
      const UPDDiscardidd = uptdiscardid[0].id;
      console.log(UPDDiscardidd,'UPDDischargeCardiddd');
 
 
   
   
   
      const UpdatedischargePatient = await this.connection.query(`UPDATE discharge_card SET
        discharge_date=?,
        discharge_status=?,
        refer_date=?,
        refer_to_hospital=?,
        reason_for_referral=?,
        operation=?,
        diagnosis=?,
        investigations=?,
        treatment_home=?,
        note=?
        WHERE id = ?`
      ,
      [
        DischargePatientOpdModule.discharge_date,
        DischargePatientOpdModule.discharge_status,
        DischargePatientOpdModule.refer_date,
        DischargePatientOpdModule.refer_to_hospital,
        DischargePatientOpdModule.reason_for_referral,
        DischargePatientOpdModule.operation,
        DischargePatientOpdModule.diagnosis,
        DischargePatientOpdModule.investigations,
        DischargePatientOpdModule.treatment_home,
        DischargePatientOpdModule.note,
        UPDDiscardidd
      ],
      )
 
 
     
 
      const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
        process.env.ADMIN_IP,
        process.env.ADMIN_DB_NAME,
        process.env.ADMIN_DB_PASSWORD,
        process.env.ADMIN_DB_USER_NAME
        )
      const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     
      dynamicConnection  = await createConnection(dynamicConnectionOptions);
 
 
      const uptdynipddid = await dynamicConnection.query(`SELECT id from opd_details WHERE opd_details = ? and Hospital_id = ?`,[id,DischargePatientOpdModule.Hospital_id])
      const UPDDynipdidd = uptdynipddid[0].id;
      console.log(UPDDynipdidd,'Dynipdidd');
 
 
 
      const uptdyndiscardid = await dynamicConnection.query(`SELECT id from discharge_card WHERE opd_details_id = ?`,[UPDDynipdidd])
      const UPDDynDiscardidd = uptdyndiscardid[0].id;
      console.log(UPDDynDiscardidd,'UPDdynDischargeCardiddd');
 
 
   
   
   
      const UpdateDyndischargePatient = await dynamicConnection.query(`UPDATE discharge_card SET
      discharge_date=?,
      discharge_status=?,
      refer_date=?,
      refer_to_hospital=?,
      reason_for_referral=?,
      operation=?,
      diagnosis=?,
      investigations=?,
      treatment_home=?,
      note=?
      WHERE id = ?`,
      [
        DischargePatientOpdModule.discharge_date,
        DischargePatientOpdModule.discharge_status,
        DischargePatientOpdModule.refer_date,
        DischargePatientOpdModule.refer_to_hospital,
        DischargePatientOpdModule.reason_for_referral,
        DischargePatientOpdModule.operation,
        DischargePatientOpdModule.diagnosis,
        DischargePatientOpdModule.investigations,
        DischargePatientOpdModule.treatment_home,
        DischargePatientOpdModule.note,
        UPDDynDiscardidd
      ],
      )
 
 
      await dynamicConnection.close();
      return  [{"data ":{
      status:"success",
     "messege":"discharged patient details updated successfully ",
     "Discharge_patient_details":await this.connection.query('SELECT * FROM discharge_card WHERE id = ?', [UPDDiscardidd])
  }}];
 
 
 
 
     
      }
 
      case 3 :{
 
        const uptdiscardid = await this.connection.query(`SELECT id from discharge_card WHERE opd_details_id = ?`,[id])
        const UPDDiscardidd = uptdiscardid[0].id;
        console.log(UPDDiscardidd,'UPDDischargeCardiddd');
 
 
     
     
     
        const UpdatedischargePatient = await this.connection.query(`UPDATE discharge_card SET
          discharge_date=?,
          discharge_status=?,
          operation=?,
          diagnosis=?,
          investigations=?,
          treatment_home=?,
          note=?
          WHERE id = ?`
        ,
        [
          DischargePatientOpdModule.discharge_date,
          DischargePatientOpdModule.discharge_status,
          DischargePatientOpdModule.operation,
          DischargePatientOpdModule.diagnosis,
          DischargePatientOpdModule.investigations,
          DischargePatientOpdModule.treatment_home,
          DischargePatientOpdModule.note,
          UPDDiscardidd
        ],
        )
 
 
       
 
        const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
          process.env.ADMIN_IP,
          process.env.ADMIN_DB_NAME,
          process.env.ADMIN_DB_PASSWORD,
          process.env.ADMIN_DB_USER_NAME
          )
        const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
       
        dynamicConnection  = await createConnection(dynamicConnectionOptions);
 
 
        const uptdynipddid = await dynamicConnection.query(`SELECT id from opd_details WHERE hos_opd_id = ? and Hospital_id = ?`,[id,DischargePatientOpdModule.Hospital_id])
        const UPDDynipdidd = uptdynipddid[0].id;
        console.log(UPDDynipdidd,'Dynipdidd');
 
 
 
        const uptdyndiscardid = await dynamicConnection.query(`SELECT id from discharge_card WHERE opd_details_id = ?`,[UPDDynipdidd])
        const UPDDynDiscardidd = uptdyndiscardid[0].id;
        console.log(UPDDynDiscardidd,'UPDdynDischargeCardiddd');
 
 
     
     
     
        const UpdateDyndischargePatient = await dynamicConnection.query(`UPDATE discharge_card SET
        discharge_date=?,
        discharge_status=?,
        operation=?,
        diagnosis=?,
        investigations=?,
        treatment_home=?,
        note=?
        WHERE id = ?`,
        [
          DischargePatientOpdModule.discharge_date,
          DischargePatientOpdModule.discharge_status,
          DischargePatientOpdModule.operation,
          DischargePatientOpdModule.diagnosis,
          DischargePatientOpdModule.investigations,
          DischargePatientOpdModule.treatment_home,
          DischargePatientOpdModule.note,
          UPDDynDiscardidd
        ],
        )
 
 
        await dynamicConnection.close();
        return  [{"data ":{
        status:"success",
       "messege":"discharged patient details updated successfully ",
       "Discharge_patient_details":await this.connection.query('SELECT * FROM discharge_card WHERE id = ?', [UPDDiscardidd])
    }}];
 
 
       
        }
 
  }
 
}catch(error){
  if(dynamicConnection){
    dynamicConnection.close();
  }
  console.error('Error inserting data:', error);
}
}
 
 
}