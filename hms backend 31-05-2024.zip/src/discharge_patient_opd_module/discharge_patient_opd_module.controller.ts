/* eslint-disable prettier/prettier */
import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { DischargePatientOpdModuleService } from './discharge_patient_opd_module.service';
import {DischargePatientOpdModule} from './entities/discharge_patient_opd_module.entity'
@Controller('discharge-patient-opd-module')
export class DischargePatientOpdModuleController {
  constructor(private readonly dischargePatientOpdModuleService: DischargePatientOpdModuleService) {}

  @Post()
  create(@Body() DischargePatientOpdModule: DischargePatientOpdModule) {
    return this.dischargePatientOpdModuleService.create(DischargePatientOpdModule);
  }

  @Get()
  findAll() {
    return this.dischargePatientOpdModuleService.findAll();
  }

  @Patch('/:id')
  update(@Param('id') id: number, @Body() DischargePatientOpdModule: DischargePatientOpdModule) {
    return this.dischargePatientOpdModuleService.update(id, DischargePatientOpdModule);
  }
 
}