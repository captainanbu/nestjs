export class InternalAppointmentCharge {}
