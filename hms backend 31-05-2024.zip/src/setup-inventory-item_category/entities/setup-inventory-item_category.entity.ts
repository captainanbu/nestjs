export class SetupInventoryItemCategory {
    id:number;
    item_category:string;
    is_active:string;
    description:string;
    created_at:Date;
    hospital_item_category_id:number;
    Hospital_id:number;
}
