export class Otp {}
