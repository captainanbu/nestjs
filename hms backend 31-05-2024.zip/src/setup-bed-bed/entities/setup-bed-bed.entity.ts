export class SetupBedBed {
    id:number;
    name:string;
    bed_type_id:number;
    bed_group_id:number;
    is_active:string;
    created_at:Date;
    hospital_bed_id:number;
    Hospital_id:number;
}
