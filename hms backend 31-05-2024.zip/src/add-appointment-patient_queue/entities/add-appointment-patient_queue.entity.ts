export class AddAppointmentPatientQueue {}
