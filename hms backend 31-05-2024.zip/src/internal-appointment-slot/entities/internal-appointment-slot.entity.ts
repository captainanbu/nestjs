export class InternalAppointmentSlot {}
