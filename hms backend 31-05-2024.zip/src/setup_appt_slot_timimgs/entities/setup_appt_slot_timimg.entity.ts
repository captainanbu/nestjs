/* eslint-disable prettier/prettier */
export class SetupApptSlotTimimg {
    id:number;
    day:string;
    staff_id:number;
    global_shift_id:number;
    start_time:string;
    end_time:string;
    Hospital_id:number
    }
