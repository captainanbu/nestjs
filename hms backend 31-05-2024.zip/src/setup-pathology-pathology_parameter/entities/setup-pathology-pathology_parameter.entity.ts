export class SetupPathologyPathologyParameter {
    id:number;
    parameter_name:string;
    test_value:string;
    reference_range:string;
    gender:string;
    unit:number;
    description:string;
    created_at:Date;
    hospital_pathology_parameter_id:number;
    Hospital_id:number;

}
