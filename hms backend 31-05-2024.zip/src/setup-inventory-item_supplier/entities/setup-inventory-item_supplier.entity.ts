export class SetupInventoryItemSupplier {
    id:number;
    item_supplier:string;
    phone:number;
    email:string;
    address:string;
    contact_person_name:string;
    contact_person_phone:number;
    contact_person_email:string;
    description:Text;
    created_at:Date;
    hospital_item_supplier_id:number;
    Hospital_id:number;

}
