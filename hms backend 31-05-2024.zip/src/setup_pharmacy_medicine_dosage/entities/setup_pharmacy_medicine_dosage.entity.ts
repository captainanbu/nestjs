export class SetupPharmacyMedicineDosage {
    id:number;
    medicine_category_id:number;
    dosage:string;
    charge_units_id:number;
    created_at:Date;
    hospital_medicine_dosage_id:number;
    Hospital_id:number;

}
