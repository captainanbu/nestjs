export class SetupFindingsFinding {
    id:number;
    name:string;
    description:string;
    finding_category_id:number;
    created_at:Date;
    hospital_finding_id:number;
    Hospital_id:number;
}
