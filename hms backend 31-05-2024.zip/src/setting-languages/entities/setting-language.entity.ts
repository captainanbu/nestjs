export class SettingLanguage {
    id:number;
    language:string;
    short_code:string;
    country_code:string;
    is_deleted:string;
    is_rtl:string;
    is_active:string;
    created_at:Date;
    updated_at:Date;
}
