export class SetupReferralReferralCategory {
    id:number;
    name:string;
    is_active:string;
    created_at:Date;
    Hospital_id:number;
    hospital_referral_category_id:number;
}
