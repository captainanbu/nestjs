export class SetupBedBedType {
    id:number;
    name:string;
    created_at:Date;
    hospital_bed_type_id:number;
    Hospital_id:number;

}
