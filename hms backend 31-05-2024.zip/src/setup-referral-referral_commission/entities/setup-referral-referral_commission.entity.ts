export class SetupReferralReferralCommission {
    id:number;
    referral_category_id:number;
    referral_type_id:number;
    commission:number;
    is_active:number;
    hospital_referral_commission_id:number;
    Hospital_id:number;
}
