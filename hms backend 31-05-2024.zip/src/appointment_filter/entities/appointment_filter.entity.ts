export class AppointmentFilter {}
