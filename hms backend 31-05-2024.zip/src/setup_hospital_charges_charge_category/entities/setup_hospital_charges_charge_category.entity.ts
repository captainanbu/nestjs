export class SetupHospitalChargesChargeCategory {
    id:number;
    charge_type_id:number;
    name:string;
    description:string;
    short_code:string;
    is_default:string;
    created_at:Date;
    hospital_charge_categories_id:number;
    Hospital_id:number;
}