export class SettingsModulesPatient {
    id:number;
    name:string;
    is_active:number;
}
