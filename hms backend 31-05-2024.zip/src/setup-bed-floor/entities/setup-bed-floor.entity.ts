export class SetupBedFloor {
    id:number;
    name:string;
    description:string;
    created_at:Date;
    hospital_floor_id:number;
    Hospital_id:number;
}
