import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';

import { Connection, createConnection } from 'typeorm';
import { DynamicDatabaseService } from 'src/dynamic_db.service';
import { MysqlConnectionOptions } from 'typeorm/driver/mysql/MysqlConnectionOptions';
import { InternalOpdPayment } from './entities/internal-opd-payment.entity';
import internal from 'stream';

@Injectable()
export class InternalOpdPaymentService {
  constructor(@InjectConnection() private connection: Connection,  
  @Inject(forwardRef(() => DynamicDatabaseService)) private dynamicDbService: DynamicDatabaseService) {}
  
async create(InternalOpdPayment: InternalOpdPayment) {
  let dynamicConnection;
  

 try {

      
  
  let section;
console.log("ddddddd");

const [case_id] = await this.connection.query(`select case_reference_id,patient_id from opd_details where id = ?`,[InternalOpdPayment.opd_id])
console.log("fffffff")

  const HOSaddRow = await this.connection.query(
      `INSERT INTO transactions(type,section, case_reference_id,patient_id, opd_id,
         payment_date, amount, payment_mode, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)`,
    [ 
      'Payment',
      'OPD',
      case_id.case_reference_id,
      case_id.patient_id, 
    InternalOpdPayment.opd_id,
    InternalOpdPayment.payment_date,
    InternalOpdPayment.amount,
    InternalOpdPayment.payment_mode,
    InternalOpdPayment.note,
   ],
  );
console.log("112233",HOSaddRow,InternalOpdPayment.payment_mode,    InternalOpdPayment.amount);

  const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(

      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
      )
     
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     dynamicConnection = await createConnection(dynamicConnectionOptions);
   
     console.log("sssss");
let AdminCaseRef;
let AdminOpd;
      const [opd_payment] = await dynamicConnection.query(`select id,case_reference_id,patient_id from opd_details where Hospital_id = ?
      and hos_opd_id = ?`, [
        InternalOpdPayment.Hospital_id,
        InternalOpdPayment.opd_id
      ])

      AdminCaseRef =opd_payment.case_reference_id
      AdminOpd = opd_payment.id
      console.log("opd_payment",opd_payment);
     


    
     const AdminaddRow = await dynamicConnection.query(
      `INSERT INTO transactions(type,section, case_reference_id,
        patient_id, opd_id, payment_date, amount, 
        Payment_mode, note,Hospital_id,hos_transaction_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?,?)`,
    [ 'Payment',
      'OPD',
    AdminCaseRef,
    opd_payment.patient_id, 
    AdminOpd,
      InternalOpdPayment.payment_date,
      InternalOpdPayment.amount,
      InternalOpdPayment.payment_mode,
      InternalOpdPayment.note,
      InternalOpdPayment.Hospital_id,
      HOSaddRow.insertId
   ],
  );
  if(dynamicConnection){
      await dynamicConnection.close();       
    }
  return       [
      {"data":{"id ":HOSaddRow.insertId,
    "status":"success",
    "messege":"Payments  added successfully inserted",
    "inserted_data": await this.connection.query('SELECT * FROM transactions WHERE id = ?', [HOSaddRow.insertId])
    }}
  ]
 } catch (error) {
  if(dynamicConnection){
      await dynamicConnection.close();
     console.log(error);       
    }
    return [{
      "status":"Failed",
      "error":error
    }]
 }
}


async findALL(patient_id:number,opd_id:number) {
  const opd_payments = await this.connection.query(`select concat("TRID",transactions.id) as transaction_ID,transactions.payment_date,transactions.note,
  transactions.payment_mode,transactions.amount from transactions where patient_id = ? and opd_id =? `,[patient_id,opd_id])
  return opd_payments;
}

async update(id:string,InternalOpdPayment: InternalOpdPayment) {
  let dynamicConnection;
  try{
    const result = await this.connection.query(
      `update transactions SET  payment_date = ?, amount = ?, payment_mode = ?, note = ? where id = ?`,
      [
        InternalOpdPayment.payment_date,
        InternalOpdPayment.amount,
        InternalOpdPayment.payment_mode,
        InternalOpdPayment.note,
        id
      ]
    );
    console.log("rrrrrrrrr");
    
    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
    )
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
    dynamicConnection = await createConnection(dynamicConnectionOptions);

    console.log("ZZZ", id,
    InternalOpdPayment.Hospital_id);

const [opdpaymentId] = await dynamicConnection.query(`select id from transactions where 
hos_transaction_id = ? and Hospital_id = ?`,[
  id,
  InternalOpdPayment.Hospital_id
])
console.log("ddd",opdpaymentId);

const repo = await dynamicConnection.query(
  `update transactions SET payment_date = ?, amount = ?, payment_mode = ?, note = ?  where  id = ?`,
  [
    InternalOpdPayment.payment_date,
        InternalOpdPayment.amount,
        InternalOpdPayment.payment_mode,
        InternalOpdPayment.note,
        opdpaymentId.id
  ]
)
console.log("kkkkkkk");
if(dynamicConnection){
  await dynamicConnection.close();       
}
return [{"data":{
  status:"success",
  "message":"transactions details updated successfully",
  "updated_values":await this.connection.query(`select * from transactions where id = ?`,[id])
}}];
  }
  catch(error){
    if(dynamicConnection){
      await dynamicConnection.close();             
    }
    console.log(error);

return [
  {status:"falied",
"message":"cannot update transactions profile",
"error":error
}
]
  }


  }


  async remove(id:string,hos_id:number) {
    let dynamicConnection;
    try{

      const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
  
        process.env.ADMIN_IP,
        process.env.ADMIN_DB_NAME,
        process.env.ADMIN_DB_PASSWORD,
        process.env.ADMIN_DB_USER_NAME
        )
      const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     
      dynamicConnection  = await createConnection(dynamicConnectionOptions);

      const delpayment = await dynamicConnection.query(`
      update transactions set is_deleted = 1 
      where Hospital_id = ? and hos_transaction_id = ?`,[hos_id,id])

      const result = await this.connection.query(`delete from transactions where id = ?`,[id]);
      if(dynamicConnection) {
        await dynamicConnection.close();
      }
      return [{
        "status":"success",
        "message":"id:"+id+"deleted successfully"
      }]

    }catch (error) {
      if(dynamicConnection){
        await dynamicConnection.close();
      }
      return error
    }
  }
}

