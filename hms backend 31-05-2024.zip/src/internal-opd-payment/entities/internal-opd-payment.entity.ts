export class InternalOpdPayment {
    id: number;
    payment_date:Date;
    note:string;
    payment_mode:string;
    amount:number;
    opd_id:number;
    patient_id:number;
    received_by:number;
    Hospital_id: number;
    hos_transaction_id: number;
  }
  
