import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { InternalOpdPaymentService } from './internal-opd-payment.service';
import { InternalOpdPayment } from './entities/internal-opd-payment.entity';


@Controller('internal-opd-payment')
export class InternalOpdPaymentController {
  constructor(private readonly internalOpdPaymentService: InternalOpdPaymentService) {}

  @Post()
  create(@Body() InternalOpdPayment: InternalOpdPayment) {
    return this.internalOpdPaymentService.create(InternalOpdPayment);
  }

  @Get()
  findAll(@Query('patient_id')patient_id:number,@Query('opd_id')opd_id:number) {
    return this.internalOpdPaymentService.findALL(patient_id,opd_id);
  }

  @Patch(':id')
  update(@Param('id') id:string, @Body() InternalOpdPayment: InternalOpdPayment){
    return this.internalOpdPaymentService.update(id, InternalOpdPayment);
  }

  @Delete(':id')
  remove(@Param('id') id: string,@Query('hos_id') hos_id:number) {
    return this.internalOpdPaymentService.remove(id,hos_id);
  }

}
