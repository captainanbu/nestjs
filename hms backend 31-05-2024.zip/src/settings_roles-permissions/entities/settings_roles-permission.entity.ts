export class SettingsRolesPermission {
    id:number;
    name:string;
    slug:string;
    is_active:number;
    is_system:number;
    is_superadmin:number;
    created_at:Date;
    hospital_roles_id:number;
    hospital_id:number;
}
