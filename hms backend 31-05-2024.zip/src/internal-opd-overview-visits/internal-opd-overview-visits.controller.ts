/* eslint-disable prettier/prettier */
import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { InternalOpdOverviewVisitsService } from './internal-opd-overview-visits.service';
import {InternalOpdOverviewVisit} from './entities/internal-opd-overview-visit.entity'
 
@Controller('internal-opd-overview-visits')
export class InternalOpdOverviewVisitsController {
  constructor(private readonly internalOpdOverviewVisitsService: InternalOpdOverviewVisitsService) {}
 
  @Post()
  create(@Body() InternalOpdOverviewVisit:InternalOpdOverviewVisit) {
    return this.internalOpdOverviewVisitsService.create(InternalOpdOverviewVisit);
  }
 
  @Get()
  findAll(@Query('patient_id')patient_id:number,@Query('visit_details_id')visit_details_id:number) {
    return this.internalOpdOverviewVisitsService.findAll(patient_id,visit_details_id);
  }
 
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.internalOpdOverviewVisitsService.findone(id);
  }
 
 
  @Patch(':id')
  update(@Param('id') id:string, @Body() InternalOpdOverviewVisit:InternalOpdOverviewVisit){
    return this.internalOpdOverviewVisitsService.update(+id, InternalOpdOverviewVisit);
  }
 
 
  @Delete('/:id')
async remove(@Param('id') id: number,@Query('Hospital_id') Hospital_id: number): Promise<{ status: string; message: string }> {
 
    const deletevisit = await this.internalOpdOverviewVisitsService.remove(id,Hospital_id);
    return {
      status: 'success',
      message: `id: ${id} deleted successfully`,
    };
 
 
  }
 
 
}