/* eslint-disable prettier/prettier */
import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection, createConnection } from 'typeorm';
import { DynamicDatabaseService } from 'src/dynamic_db.service';
import { MysqlConnectionOptions } from 'typeorm/driver/mysql/MysqlConnectionOptions';
import {InternalOpdOverviewVisit} from './entities/internal-opd-overview-visit.entity'
@Injectable()
export class InternalOpdOverviewVisitsService {
  constructor(@InjectConnection() private connection: Connection,
  @Inject(forwardRef(() => DynamicDatabaseService)) private dynamicDbService: DynamicDatabaseService
  ){}
 
 
  async create ( InternalOpdOverviewVisit:InternalOpdOverviewVisit) {
    let dynamicConnection;
    try{
      const HOSpatient = await this.connection.query('select * from patients where id =?',[InternalOpdOverviewVisit.patient_id] )
       
      let HOspatientmobileno = HOSpatient[0].mobileno
      console.log("rrrrr",HOSpatient);
     
   
    let  HOSTrimmedmobileno = HOspatientmobileno.startsWith('91') ? HOspatientmobileno.slice(2):HOspatientmobileno;
 
    const [HOSstaff] = await this.connection.query('select * from staff where id = ?',[InternalOpdOverviewVisit.cons_doctor])
 
    let HOSdoctoremail = HOSstaff.email
 
    console.log("zzzzzzzz",HOSdoctoremail)
   
const tpa_id = await this.connection.query(`select organisation_id from visit_details where opd_details_id = ?`,[InternalOpdOverviewVisit.opd_details_id])
 
const tpaid = tpa_id.organisation_id;
 
      const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
        process.env.ADMIN_IP,
        process.env.ADMIN_DB_NAME,
        process.env.ADMIN_DB_PASSWORD,
        process.env.ADMIN_DB_USER_NAME
        )
      const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     
      dynamicConnection  = await createConnection(dynamicConnectionOptions);
     
      const patientInHos = await dynamicConnection.query('select patients.id from patients where patients.mobileno = ? or patients.mobileno = ?',[
        HOspatientmobileno,HOSTrimmedmobileno
      ])
      console.log(patientInHos,"patientInHos");
     
 
 
            const [staffInHos] = await dynamicConnection.query('select staff.id from staff where staff.email = ?',[
            HOSdoctoremail
             ])
     
             console.log(staffInHos,"ssss");
 
 
     
       
let HOSpatientId;
 
 
if(patientInHos[0]){
  console.log("sssssddddd")
  HOSpatientId = patientInHos[0].id
 
 
}else{
 
  const datestring =  HOSpatient[0].dob;
  const dateObject = new Date(datestring);
  const Timestamp = dateObject.toISOString().replace('T',' ').replace(/\.\d+2$/,'');
 
 
 
 
 
}
 
const [staffEmailInHOS] = await this.connection.query(`select email from staff where id = ?`,[InternalOpdOverviewVisit.cons_doctor])
console.log("staffEmailAdmin",staffEmailInHOS.email);
 
const [adminStaff] = await dynamicConnection.query(`select id from staff where email = ?`,[staffEmailInHOS.email])
let adminStaffId = adminStaff.id
 
console.log("gggg",adminStaff);
 
 
const [case_id] = await this.connection.query(`select case_reference_id from opd_details where id = ?`,[InternalOpdOverviewVisit.opd_details_id])
 
const case_ref = case_id.case_reference_id;
 
console.log("sdfsdf",case_ref);
 
 
 
var HOStransaction_id:number
 
 
 
 
const HOSamount = await this.connection.query(`
select charges.standard_charge,tax_category.percentage tax_percentage, round((charges.standard_charge+
  (charges.standard_charge*((tax_category.percentage)/100))),2) amount from
charges join tax_category on charges.tax_category_id = tax_category.id
where charges.id = ?`,[InternalOpdOverviewVisit.charge_id])
 
let HOspatient_charges_id;
 
 
const HOSPatient_charges = await this.connection.query(
  `insert into patient_charges(
    date,
    opd_id,
    qty,
    charge_id,
    standard_charge,
    tax,
    apply_charge,
    amount
    ) values(?,?,?,?,?,?,?,?)`,[
      InternalOpdOverviewVisit.date,
      InternalOpdOverviewVisit.opd_details_id,
      1,
      InternalOpdOverviewVisit.charge_id,
      HOSamount[0].standard_charge,      
      HOSamount[0].tax_percentage,
      InternalOpdOverviewVisit.apply_charge,
      HOSamount[0].amount
    ]
)
console.log("10001100011000110100101001010010");
 
 HOspatient_charges_id = HOSPatient_charges.insertId
 
console.log(HOspatient_charges_id,"ssss");
 
 
const HOStransactions = await this.connection.query(`
 
insert into transactions (
  type,
  opd_id,
  section,
  patient_id,
  case_reference_id,
  patient_charges_id,
  amount,
  payment_mode,
  payment_date
  ) values
  (?,?,?,?,?,?,?,?,?)`,[
    'payment',
    InternalOpdOverviewVisit.opd_details_id,
    'OPD',
    InternalOpdOverviewVisit.patient_id,
    case_ref,
    HOspatient_charges_id,
    HOSamount.amount,
    InternalOpdOverviewVisit.payment_mode,
    InternalOpdOverviewVisit.payment_date,
   
  ])
  HOStransaction_id = HOStransactions.insertId
  console.log(HOStransaction_id,"idddddddddddddd");
  console.log(HOStransaction_id,"ccccccccc");
 
 
 
  const HOSvisitInsert = await this.connection.query(`
  insert into visit_details(
    opd_details_id,
    organisation_id,
    patient_charge_id,
    transaction_id,
    case_type,
    cons_doctor,
    appointment_date,
    live_consult,
    payment_mode,
    symptoms_type,
    symptoms,
    bp,
    height,
    weight,
    pulse,
    temperature,
    respiration,
    known_allergies,
    note
    ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ,[
      InternalOpdOverviewVisit.opd_details_id,
      tpaid,
      HOspatient_charges_id,
      HOStransaction_id,
      "",
      InternalOpdOverviewVisit.cons_doctor,
      InternalOpdOverviewVisit.date+" "+InternalOpdOverviewVisit.time,
      InternalOpdOverviewVisit.live_consult,
      InternalOpdOverviewVisit.payment_mode,
      InternalOpdOverviewVisit.symptoms_type,
      InternalOpdOverviewVisit.symptoms,
      InternalOpdOverviewVisit.bp,
      InternalOpdOverviewVisit.height,
      InternalOpdOverviewVisit.weight,
      InternalOpdOverviewVisit.pulse,
      InternalOpdOverviewVisit.temperature,
      InternalOpdOverviewVisit.respiration,
      InternalOpdOverviewVisit.known_allergies,
      InternalOpdOverviewVisit.note
    ])
    console.log(HOSvisitInsert,"]][[]][[");
   
    const HOSvisit_details_id = HOSvisitInsert.insertId  
 
    console.log(HOSvisit_details_id,"HOSvisit_details_id");
    console.log("nnnnnnnn");
   
   
 
 
 
 
 
// ##################################################################################################################################################################
 
const [opd_details_id] = await dynamicConnection.query(`select id from opd_details where hos_opd_id = ? and Hospital_id = ?`,[InternalOpdOverviewVisit.opd_details_id,InternalOpdOverviewVisit.Hospital_id])
 
 const opd_id = opd_details_id.id;
 console.log("hhhh",opd_id);
 
 
 
 const [cases_id] = await dynamicConnection.query(`select case_reference_id from opd_details where hos_opd_id = ? and Hospital_id = ?`,[InternalOpdOverviewVisit.opd_details_id,InternalOpdOverviewVisit.Hospital_id])
 
 const cases = cases_id.case_reference_id
 
 console.log("llll",cases);
 
 
const [getAdminChargeId] = await dynamicConnection.query(`select id  from charges
where Hospital_id = ? and hospital_charges_id = ?`,
[InternalOpdOverviewVisit.Hospital_id,
  InternalOpdOverviewVisit.charge_id
])
console.log("Hospital ID:", InternalOpdOverviewVisit.Hospital_id);
console.log("Patient Charge ID:", InternalOpdOverviewVisit.charge_id);
console.log(getAdminChargeId,"xxxxxxxxssss");
 
const Patient_charges = await dynamicConnection.query(
  `insert into patient_charges(
    date,
    opd_id,
    qty,
    charge_id,
    standard_charge,
    tax,
    apply_charge,
    amount,Hospital_id,hos_patient_charges_id
    ) values(?,?,?,?,?,?,?,?,?,?)`,[
      InternalOpdOverviewVisit.date,
      opd_id,
      1,
      getAdminChargeId.id,
      HOSamount[0].standard_charge,      
        HOSamount[0].tax_percentage,
        InternalOpdOverviewVisit.apply_charge,
        HOSamount[0].amount,
        InternalOpdOverviewVisit.Hospital_id,
        HOSPatient_charges.insertId
    ]
)
 
const adminpatient_charges_id = Patient_charges.insertId
 
console.log(adminpatient_charges_id,"ssss");
let adminTransaction_id;
 
  try{
   
  const transactions = await dynamicConnection.query(`
  insert into transactions (
  type,
  opd_id,
  section,
  patient_id,
  case_reference_id,
  patient_charges_id,
  amount,
  payment_mode,
  payment_date,Hospital_id,
  hos_transaction_id
  ) values
  (?,?,?,?,?,?,?,?,?,?,?)`,[
    'payment',
    opd_id,
    'OPD',
    HOSpatientId,
    cases,
    adminpatient_charges_id,
    HOSamount.amount,
    InternalOpdOverviewVisit.payment_mode,
    InternalOpdOverviewVisit.payment_date,
    InternalOpdOverviewVisit.Hospital_id,
    HOStransactions.insertId
  ])
  adminTransaction_id = transactions.insertId
  console.log(adminTransaction_id,"11221121122112");
} catch (error) {
  return "error in admin transaction insert"
}
 
 
 
  const visitInsert = await dynamicConnection.query(`
  insert into visit_details(
    opd_details_id,
    patient_charge_id,
    transaction_id,
    case_type,
    cons_doctor,
    appointment_date,
    live_consult,
    payment_mode,
    symptoms_type,
    symptoms,
    bp,
    height,
    weight,
    pulse,
    temperature,
    respiration,
    known_allergies,
    note,
    Hospital_id,
    hos_visit_id
  ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
 
  [
    opd_id,
    adminpatient_charges_id,
    adminTransaction_id,
    "",
    adminStaffId,
    InternalOpdOverviewVisit.date+" "+InternalOpdOverviewVisit.time,
    InternalOpdOverviewVisit.live_consult,
    InternalOpdOverviewVisit.payment_mode,
    InternalOpdOverviewVisit.symptoms_type,
    InternalOpdOverviewVisit.symptoms,
    InternalOpdOverviewVisit.bp,
    InternalOpdOverviewVisit.height,
    InternalOpdOverviewVisit.weight,
    InternalOpdOverviewVisit.pulse,
    InternalOpdOverviewVisit.temperature,
    InternalOpdOverviewVisit.respiration,
    InternalOpdOverviewVisit.known_allergies,
    InternalOpdOverviewVisit.note,
    InternalOpdOverviewVisit.Hospital_id,
    HOSvisitInsert.insertId
  ]
  )
  console.log("vvvvvvv")
 
 
 
 await dynamicConnection.close();
 
return [{
  "status":"success",
  "message":"opd details added successfully",
   "inserted_details ":await this.connection.query('select * from visit_details where id = ?',[HOSvisitInsert.insertId] )
}];
    }
 
catch (error) {  
  if(dynamicConnection){
    await dynamicConnection.close();
    return error
 
}
}
 
}
 
 
  async findAll(patient_id:number,visit_details_id:number) {
    const visits = await this.connection.query(`    
    select CONCAT('OPDN', visit_details.opd_details_id) as opd_NO,CONCAT ('OCID', visit_details.id) AS OPD_checkup_ID,opd_details.case_reference_id as case_id,
   visit_details.appointment_date,
   CONCAT(staff.name, ' ', staff.surname, staff.employee_id)  AS consultant,visit_details.refference,visit_details.symptoms from visit_details
   join opd_details ON visit_details.opd_details_id = opd_details.id
   join staff ON visit_details.cons_doctor = staff.id where patient_id = ? and visit_details.opd_details_id = ?`,[patient_id,visit_details_id])
    return visits;
  }
 
 
  async findone(id:String) {
    const visit = await this.connection.query(`select concat("OCID",visit_details.id) as OPD_checkup_id,opd_details.id as OPD_ID, opd_details.case_reference_id, visit_details.patient_old, 
    patients.gender, patients.mobileno, patients.address, blood_bank_products.name as blood_group,
    visit_details.weight,visit_details.pulse,visit_details.respiration,visit_details.appointment_date,
    visit_details.casualty,visit_details.organisation_id as TPA,visit_details.note,visit_details.symptoms,visit_details.symptoms_type,
    concat("OPDN",visit_details.opd_details_id) as OPD_ID, concat(patients.patient_name,"(",patients.id,")") as patient_name,
    patients.guardian_name,patients.marital_status,patients.email,
    concat(patients.age,"years"," ",patients.month,"month"," ",patients.day,"day") as age,
    visit_details.height,visit_details.bp,visit_details.temperature,visit_details.known_allergies,visit_details.case_type,
    visit_details.refference,CONCAT( staff.name, ' ', staff.surname,((staff.employee_id))) AS doctor,
    staff.id,patient_charges.charge_id,patient_charges.standard_charge,organisation.id,transactions.payment_mode,transactions.amount,transactions.payment_date
    from visit_details
    left join opd_details on visit_details.opd_details_id = opd_details.id
    left join patients on opd_details.patient_id = patients.id
    left join staff on visit_details.cons_doctor = staff.id
    left join blood_bank_products on patients.blood_bank_product_id = blood_bank_products.id
    left join organisation on visit_details.organisation_id = organisation.id
    left join transactions on visit_details.transaction_id = transactions.id
    left join patient_charges on visit_details.patient_charge_id = patient_charges.id
    where opd_details_id = ?`,[id]);
    if (visit.length === 1) {
      return visit
    } else {
      return null;
    }
  }
 
 
 
 
async update(id:number,  InternalOpdOverviewVisit:InternalOpdOverviewVisit){
  let dynamicConnection;
 
try{
    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
 
      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
      )
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
 
    dynamicConnection = await createConnection(dynamicConnectionOptions);
 
    console.log("dddd");
 
   
   
    const [getTransc] = await this.connection.query(`select transaction_id from visit_details where id = ?`,[id])
 
 
    const HosTransaction = await this.connection.query(`update transactions set amount = ?,
    payment_mode = ?,
    note = ?,
    payment_date = ?
    where id = ?`,[
      InternalOpdOverviewVisit.amount,
      InternalOpdOverviewVisit.payment_mode,
      InternalOpdOverviewVisit.note,
      InternalOpdOverviewVisit.payment_date,
      getTransc.transaction_id
    ])
 
    console.log("rrrrrr");
   
    const updateHosVisit = await this.connection.query(`update visit_details set height = ?,
    weight = ?,
    pulse = ?,
    bp = ?,
    temperature = ?,
    respiration = ?,
    known_allergies = ?,
    symptoms_type = ?,
    symptoms = ?,
    note = ?,
    appointment_date = ?,
    case_type = ?,
    casualty = ?,
    patient_old = ?,
    refference = ?,
    cons_doctor = ?
    where id = ?`,[
      InternalOpdOverviewVisit.height,
      InternalOpdOverviewVisit.weight,
      InternalOpdOverviewVisit.pulse,
      InternalOpdOverviewVisit.bp,
      InternalOpdOverviewVisit.temperature,
      InternalOpdOverviewVisit.respiration,
      InternalOpdOverviewVisit.known_allergies,
      InternalOpdOverviewVisit.symptoms_type,
      InternalOpdOverviewVisit.symptoms,
      InternalOpdOverviewVisit.note,
      InternalOpdOverviewVisit.appointment_date,
      InternalOpdOverviewVisit.case_type,
      InternalOpdOverviewVisit.casualty,
      InternalOpdOverviewVisit.patient_old,
      InternalOpdOverviewVisit.refference,
      InternalOpdOverviewVisit.cons_doctor,
      id
    ])
 
    console.log("jjjj");
   
    const [getHosDoccMail] = await this.connection.query(`select email from staff where id = ?`,[InternalOpdOverviewVisit.cons_doctor])
 
   
    console.log("ffff");
   
 
 
 
const [getAdminDocId] = await dynamicConnection.query(`select id from staff where email = ?`,[getHosDoccMail.email])
 
const [getHosTransc] = await dynamicConnection.query(`select transaction_id from visit_details where Hospital_id =? and hos_visit_id = ?`,[InternalOpdOverviewVisit.Hospital_id,id])
 
const [getHosvisit] = await dynamicConnection.query(`select id from visit_details where Hospital_id = ? and hos_visit_id = ?`,[InternalOpdOverviewVisit.Hospital_id,id])
 
const AdminTransaction = await dynamicConnection.query(`update transactions set amount = ?,
payment_mode = ?,
note = ?,
payment_date = ?
where id = ?`,[
  InternalOpdOverviewVisit.amount,
  InternalOpdOverviewVisit.payment_mode,
  InternalOpdOverviewVisit.note,
  InternalOpdOverviewVisit.payment_date,
  getHosTransc.transaction_id
])
 
console.log("AdminTransaction",AdminTransaction);
 
 
 
 
const updateAdminVisit = await dynamicConnection.query(`update visit_details set height = ?,
weight = ?,
pulse = ?,
bp = ?,
temperature = ?,
respiration = ?,
known_allergies = ?,
symptoms_type = ?,
symptoms = ?,
note = ?,
appointment_date = ?,
case_type = ?,
casualty = ?,
patient_old = ?,
refference = ?,
cons_doctor = ?
where id = ?`,[
  InternalOpdOverviewVisit.height,
  InternalOpdOverviewVisit.weight,
  InternalOpdOverviewVisit.pulse,
  InternalOpdOverviewVisit.bp,
  InternalOpdOverviewVisit.temperature,
  InternalOpdOverviewVisit.respiration,
  InternalOpdOverviewVisit.known_allergies,
  InternalOpdOverviewVisit.symptoms_type,
  InternalOpdOverviewVisit.symptoms,
  InternalOpdOverviewVisit.note,
  InternalOpdOverviewVisit.appointment_date,
  InternalOpdOverviewVisit.case_type,
  InternalOpdOverviewVisit.casualty,
  InternalOpdOverviewVisit.patient_old,
  InternalOpdOverviewVisit.refference,
  getAdminDocId.id,
  getHosvisit.id
])
console.log("sdvhjdfvjh",updateAdminVisit);
 
await dynamicConnection.close();
 
  return  [{
    "status":"success",
    "messege":"opd updated successfully",
    "updated_details":await this.connection.query('select * from visit_details where id = ?',[id])
  }];
} catch (error) {
  if (dynamicConnection) {
    await dynamicConnection.close();
  }
  return "error is : "+error
}
}
 
 
async remove(id: number, Hospital_id: number): Promise<{ [key: string]: any }[]> {
  try {
    // Delete from visit_details
    console.log("uuuuuuu");
 
    // Get patient_charge_id from visit_details
    const patientChargeResult = await this.connection.query('SELECT patient_charge_id FROM visit_details WHERE id = ?', [id]);
    const patientChargeId = patientChargeResult[0]?.patient_charge_id;
 
    console.log("ttttt", patientChargeId);
 
    if (patientChargeId) {
      // Delete from patient_charges using patient_charge_id
      await this.connection.query('DELETE FROM patient_charges WHERE id = ?', [patientChargeId]);
    }
 
    // Get transaction_id from visit_details
    const transactionResult = await this.connection.query('SELECT transaction_id FROM visit_details WHERE id = ?', [id]);
    const transactionId = transactionResult[0]?.transaction_id;
 
    console.log("rrrrrrr", transactionId);
 
    if (transactionId) {
      // Delete from transactions using transaction_id
      await this.connection.query('DELETE FROM transactions WHERE id = ?', [transactionId]);
    }
    const visitDetailsResult = await this.connection.query('DELETE FROM visit_details WHERE id = ?', [id]);
 
    return [
      {
        status: 'success',
        message: `Visit Details with id: ${id} and associated entries in the dynamic database have been deleted.`,
      },
    ];
  } catch (error) {
    console.error("Error:", error);
    throw new Error("Failed to delete records.");
  }
}
 
 
}