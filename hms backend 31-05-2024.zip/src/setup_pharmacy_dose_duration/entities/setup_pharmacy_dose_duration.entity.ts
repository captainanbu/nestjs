export class SetupPharmacyDoseDuration {
    id:number;
    name:string;
    hospital_dose_duration_id:number;
    Hospital_id:number;
}
