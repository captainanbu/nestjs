export class InternalAppointmentShift {}
