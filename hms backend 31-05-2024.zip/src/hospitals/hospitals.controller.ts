import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { HospitalsService } from './hospitals.service';
import { Hospital } from './entities/hospital.entity';


@Controller('hospitals')
export class HospitalsController {
  constructor(private readonly hospitalsService: HospitalsService) {}





  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.hospitalsService.findOne(id);
  }

  @Get(`/QR/:id`)
  findoneQR(@Param('id') id: string) {
    return this.hospitalsService.findoneQR(+id)
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() HospitalEntity:Hospital) {
    return this.hospitalsService.update(id, HospitalEntity);
  }

 
}
