import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { DynamicDatabaseService } from 'src/dynamic_db.service';
import { Connection, createConnection } from 'typeorm';
import { Hospital } from './entities/hospital.entity';
import { MysqlConnectionOptions } from 'typeorm/driver/mysql/MysqlConnectionOptions';
import { error } from 'console';


@Injectable()
export class HospitalsService {
 
  constructor(@InjectConnection() private connection: Connection,
  @Inject(forwardRef(() => DynamicDatabaseService)) private dynamicDbService: DynamicDatabaseService
){} 

  async findOne(id: string) {

    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(

      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
      )
      
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     const dynamicConnection = await createConnection(dynamicConnectionOptions);
     
    const hospitals = await dynamicConnection.query(`SELECT * FROM hospitals WHERE plenome_id = ?`, [id]);
    
    if (hospitals.length === 1) {
      return hospitals ;
    } else {
      return error;
    }
  }

async findoneQR(id:number) {

  const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(

    process.env.ADMIN_IP,
    process.env.ADMIN_DB_NAME,
    process.env.ADMIN_DB_PASSWORD,
    process.env.ADMIN_DB_USER_NAME
    )
    
  const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
   const dynamicConnection = await createConnection(dynamicConnectionOptions);

  const [getall] = await dynamicConnection.query(`SELECT * FROM hospitals WHERE plenome_id = ?`, [id])
  let resp = {
    "QR_type_id":1,
    "QR_type":"HospitalQR",
    "hospitals":getall
  }

  return resp;
}


  async update(id:string, HospitalEntity:Hospital) {
    let dynamicConnection;
    try{
      const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(

        process.env.ADMIN_IP,
        process.env.ADMIN_DB_NAME,
        process.env.ADMIN_DB_PASSWORD,
        process.env.ADMIN_DB_USER_NAME
        )
        
      const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
       dynamicConnection = await createConnection(dynamicConnectionOptions);

       const repo = await dynamicConnection.query(
        `update hospitals SET hospital_name = ?,
        contact_no = ?,
        hospital_consulting_charge = ?,
        hospital_opening_timing = ?,
        hospital_closing_timing = ?,
        address = ?,
        state = ?,
        district = ?,
        pincode = ?,
        website = ?,
        email = ?,
        hospital_reg_no = ?,
    hospital_reg_date = ?,
    hospital_reg_expiry_date = ?,
    specialty = ?,
    image = ?,
    logo = ?,
    bedcount = ?,
    overview = ?
 where plenome_id = ?
        `,[
          HospitalEntity.hospital_name,
          HospitalEntity.contact_no,
          HospitalEntity.hospital_consulting_charge,
          HospitalEntity.hospital_opening_timing,
          HospitalEntity.hospital_closing_timing,
          HospitalEntity.address,
          HospitalEntity.state,
          HospitalEntity.district,
          HospitalEntity.pincode,
          HospitalEntity.website,
          HospitalEntity.email,
          HospitalEntity.hospital_reg_no,
          HospitalEntity.hospital_reg_date,
          HospitalEntity.hospital_reg_expiry_date,
         JSON.stringify(HospitalEntity.specialty) ,
          HospitalEntity.image,
          HospitalEntity.logo,
          HospitalEntity.bedcount,
          HospitalEntity.overview,
          id
        ]
       );

       console.log("hospitals");

       return [{"data": {
        status:"success",
        "message":"hospitals details updated successfully",
        "updated values":await dynamicConnection.query(`select * from hospitals where plenome_id = ?`, [id])
       }}]
      } catch (error) {
        return [
          {status:"failed",
           "messege":"cannot update hospitals profile",
           "error":error
        }
        ]
    }
  }
}
