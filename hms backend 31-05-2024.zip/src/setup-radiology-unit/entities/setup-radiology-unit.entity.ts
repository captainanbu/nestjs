export class SetupRadiologyUnit {
    id:number;
    unit_name:string;
    unit_type:string;
    created_at:Date;
    hospital_unit_id:number;
    Hospital_id:number;
}
