export class SetupFrontOfficeAppointmentPriority {
    id:number;
    priority_status:string;
    created_at:Date;
}
