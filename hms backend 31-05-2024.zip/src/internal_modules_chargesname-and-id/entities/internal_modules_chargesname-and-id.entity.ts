export class InternalModulesChargesnameAndId {}
