import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection } from 'typeorm';

@Injectable()
export class InternalModulesChargesnameAndIdService {
  constructor(@InjectConnection() private connection: Connection)
  {}

  async findall(charge_category_id:number) {
    const charges = await this.connection.query(`select charges.id,charges.name from charges where charge_category_id = ?`,[charge_category_id]);
    console.log(charges);
    
    return charges;
  }

  async findcharges(standard_charge:number) {
    const charges_amount = await this.connection.query(`select charges.standard_charge,tax_category.percentage tax_percentage, round((charges.standard_charge+
     (charges.standard_charge*((tax_category.percentage)/100))),2) amount from
   charges join tax_category on charges.tax_category_id = tax_category.id
 where charges.id = ?`,[standard_charge])
    console.log(charges_amount);
  
    return charges_amount;
    
   }

   async find_slot_name(){
   
    const slot  = await this.connection.query(`select * from doctor_shift`);    
    return slot;
  }


}
