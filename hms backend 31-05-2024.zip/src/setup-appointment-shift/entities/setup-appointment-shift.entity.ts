export class SetupAppointmentShift {
    id:number;
    name:string;
    start_time:TimeRanges;
    end_time:TimeRanges;
    date_created:Date;
    hospital_global_shift_id:number;
    Hospital_id:number;
}
