export class SetupBloodBankProduct {
    id:number;
    name:string;
    is_blood_group:number;
    created_at:Date;
    hospital_blood_bank_products_id:number;
    Hospital_id:number;
}
