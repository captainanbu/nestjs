export class RevertDischargePatientIpdModule {


    
}
