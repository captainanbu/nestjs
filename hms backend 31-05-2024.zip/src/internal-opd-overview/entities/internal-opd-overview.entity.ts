export class InternalOpdOverview {}
