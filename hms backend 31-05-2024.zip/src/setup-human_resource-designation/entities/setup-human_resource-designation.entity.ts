export class SetupHumanResourceDesignation {
    id:number;
    designation:string;
    is_active:string;
    created_at:Date;
    hospital_staff_designation_id:number;
    Hospital_id:number;
}
