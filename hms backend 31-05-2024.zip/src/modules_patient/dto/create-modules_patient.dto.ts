export class CreateModulesPatientDto {}
