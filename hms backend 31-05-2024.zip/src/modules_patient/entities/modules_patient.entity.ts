export class ModulesPatient {}
