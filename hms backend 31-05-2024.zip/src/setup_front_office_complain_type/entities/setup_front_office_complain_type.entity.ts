export class SetupFrontOfficeComplainType {
    id:number;
    complaint_type:string;
    description:string;
    created_at:Date;
    hospital_complaint_type_id:number;
    Hospital_id:number;
}
