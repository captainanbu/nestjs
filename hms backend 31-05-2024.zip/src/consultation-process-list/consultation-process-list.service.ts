import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { ConsultationProcessList } from './entities/consultation-process-list.entity';
import { InjectConnection } from '@nestjs/typeorm';
import { DynamicDatabaseService } from 'src/dynamic_db.service';
import { Connection, createConnection } from 'typeorm';
import { MysqlConnectionOptions } from 'typeorm/driver/mysql/MysqlConnectionOptions';

@Injectable()
export class ConsultationProcessListService {
  constructor(@InjectConnection() private connection: Connection,
  @Inject(forwardRef(() => DynamicDatabaseService)) private dynamicDbService: DynamicDatabaseService

  ) {}
 async create(Entity: ConsultationProcessList) {
let dynamicConnection;
try {
  try {
    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(

      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME 
      )
      
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     dynamicConnection = await createConnection(dynamicConnectionOptions)
  } catch (error) {
    return  error
  }

const insertInHos = await this.connection.query(`insert into PT_consultation_process_list (process_name,
  process_description
) values(?,?)`,[Entity.process_name,
  Entity.process_description
])



const insertInAdmin = await dynamicConnection.query(`insert into PT_consultation_process_list (process_name,
  process_description,
  hospital_id,
  hos_PT_consultation_process_list_id
) values(?,?,?,?)`,[Entity.process_name,
  Entity.process_description,
  Entity.hospital_id,
  insertInHos.insertId
])
if(dynamicConnection){
  dynamicConnection.close()
}

return {
  "status":"success",
  "message":"Consultation process list added successfully.",
  "inserted_details":await this.connection.query(`select * from PT_consultation_process_list where id = ?`,[insertInHos.insertId])
};



} catch (error) {
  if(dynamicConnection){
    dynamicConnection.close()
  }
  return  error

}
   
  }

 async findAll() {

    const getAll = await this.connection.query(`select * from PT_consultation_process_list`)
    return getAll;
  }

async  findOne(id: number) {
    const getAll = await this.connection.query(`select * from PT_consultation_process_list where id = ?`,[id])

    return getAll;
  }


  async  findOneQR(id: number) {
    const [getAll] = await this.connection.query(`select * from PT_consultation_process_list where id = ?`,[id])
    let resp = {
      "QR_type_id":2,
      "QR_type":"consultaionProcessQR",
      "conslutation_process_details":getAll
    }

    return resp;
  }


async  update(id: number, Entity: ConsultationProcessList) {


    
let dynamicConnection;
try {
  try {
    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(

      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME 
      )
      
    const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
     dynamicConnection = await createConnection(dynamicConnectionOptions)
  } catch (error) {
    return  error
  }

const insertInHos = await this.connection.query(`update PT_consultation_process_list set process_name = ?,
  process_description = ?
where id = ?`,[Entity.process_name,
  Entity.process_description,
  id
])

console.log("sss",insertInHos);


const insertInAdmin = await dynamicConnection.query(`update  PT_consultation_process_list SET process_name = ?,
  process_description = ? where 
  hospital_id = ? and
  hos_PT_consultation_process_list_id = ?`,[Entity.process_name,
  Entity.process_description,
  Entity.hospital_id,
id])


if(dynamicConnection){
  dynamicConnection.close()
}
console.log("insertInAdmin",insertInAdmin)


return  [{"data ":{
  status:"success",
  "messege":"Consultation process list added successfully. ",
  "updated_values":await this.connection.query('SELECT * FROM PT_consultation_process_list WHERE id = ?', [id])
  }}];


} catch (error) {
  if(dynamicConnection){
    dynamicConnection.close()
  }
  return  error

}
   
  
  }

async  remove(id: string, hospital_id:number): Promise<{ [key: string]: any} []> {
    const DelAll = await this.connection.query(`delete from PT_consultation_process_list where id = ?`,[id])

    const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(

      process.env.ADMIN_IP,
      process.env.ADMIN_DB_NAME,
      process.env.ADMIN_DB_PASSWORD,
      process.env.ADMIN_DB_USER_NAME
      )


      const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
      const dynamicConnection = await createConnection(dynamicConnectionOptions);

      const deladmin = await dynamicConnection.query(`select id from PT_consultation_process_list where hos_PT_consultation_process_list_id = ? `,[id]);
      const deleteadmin = deladmin[0].id;
      console.log("deleteadmin",deleteadmin);
      
      await dynamicConnection.query(`delete from PT_consultation_process_list where id = ? and hospital_id = ?`, [deleteadmin,hospital_id])

      await dynamicConnection.close();

      return [{
        "status":" success",
        "message":" id: "+ id+"deleted successfully"
      }];
  }
}
