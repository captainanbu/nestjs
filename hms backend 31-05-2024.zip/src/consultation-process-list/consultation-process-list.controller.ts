import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { ConsultationProcessListService } from './consultation-process-list.service';
import { ConsultationProcessList } from './entities/consultation-process-list.entity';

@Controller('consultation-process-list')
export class ConsultationProcessListController {
  constructor(private readonly consultationProcessListService: ConsultationProcessListService) {}

  @Post()
  create(@Body() Entity: ConsultationProcessList) {
    return this.consultationProcessListService.create(Entity);
  }

  @Get()
  findAll() {
    return this.consultationProcessListService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.consultationProcessListService.findOne(+id);
  }
  @Get('/QR/:id')
  findOneQR(@Param('id') id: string) {
    return this.consultationProcessListService.findOneQR(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() Entity: ConsultationProcessList) {
    return this.consultationProcessListService.update(+id, Entity);
  }

  @Delete(':id')
 async remove(@Param('id') id: string, @Query('hospital_id') hospital_id:number) {

  const deletelist = await this.consultationProcessListService.remove(id,hospital_id);
  return {
    status: `success`,
    message: `id: ${id} deleted successfully`
  };
}
}
