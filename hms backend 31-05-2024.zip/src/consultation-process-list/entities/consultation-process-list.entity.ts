export class ConsultationProcessList {
    process_name:string
    process_description:string
    hospital_id:any
}
