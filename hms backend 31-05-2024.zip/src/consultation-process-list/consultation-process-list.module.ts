import { Module } from '@nestjs/common';
import { ConsultationProcessListService } from './consultation-process-list.service';
import { ConsultationProcessListController } from './consultation-process-list.controller';
import { DynamicDatabaseService } from 'src/dynamic_db.service';

@Module({
  controllers: [ConsultationProcessListController],
  providers: [ConsultationProcessListService,DynamicDatabaseService],
})
export class ConsultationProcessListModule {}
