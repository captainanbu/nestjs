export class SetupSymptomsSymptomsHead {
    id:number;
    symptoms_title:string;
    description:string;
    type:string;
    hospital_symptoms_id:number;
    Hospital_id:number;
}
