export class SetupPharmacyMedicineCategory {
    id:number;
    medicine_category:string;
    created_at:Date;
    hospital_medicine_category_id:number;
    Hospital_id:number;
}
