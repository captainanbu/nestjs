import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { SetupOperationOperationService } from './setup-operation-operation.service';
import { SetupOperationOperation } from './entities/setup-operation-operation.entity';
 
@Controller('setup-operation-operation')
export class SetupOperationOperationController {
  constructor(private readonly setupOperationOperationService: SetupOperationOperationService) {}
 
  @Post()
  create(@Body() operationEntity: SetupOperationOperation) {
    return this.setupOperationOperationService.create(operationEntity);
  }
 
  @Get()
  findAll() {
    return this.setupOperationOperationService.findAll();
  }
 
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.setupOperationOperationService.findOne(id);
  }
 
  @Patch(':id')
  update(@Param('id') id: string, @Body()  operationEntity: SetupOperationOperation) {
    return this.setupOperationOperationService.update(id,operationEntity );
  }
 
  @Delete(':id')
 async remove(@Param('id') id: string,  @Query('Hospital_id') Hospital_id: number) {
 
    const deleteoperation = await this.setupOperationOperationService.remove(id,Hospital_id);
return {
  status: 'success',
  message: `id: ${id} deleted successfully`
}
  }
}