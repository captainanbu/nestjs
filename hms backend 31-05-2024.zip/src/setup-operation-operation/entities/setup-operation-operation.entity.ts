

export class SetupOperationOperation {
    id:number;
    operation:string;
    category_id:number;
    is_active:string;
    created_at:Date;
    hospital_operation_id:number;
    Hospital_id:number;
}
