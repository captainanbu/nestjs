export class SetupFrontOfficeSource {
    id:number;
    source:string;
    description:string;
    created_at:Date;
    hospital_source_id:number;
    Hospital_id:number;
}
