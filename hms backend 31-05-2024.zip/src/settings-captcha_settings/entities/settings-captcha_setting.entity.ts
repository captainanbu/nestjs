export class SettingsCaptchaSetting {
    id:number;
    name:string;
    status:number;
    created_at:Date;
}
