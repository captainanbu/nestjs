export class AddAppointmentDoctorWise {}
