export class TpaManagement {
    id:number;
    organisation_name:string;
    code:string;
    contact_no:number;
    address:string;
    contact_person_name:string;
    contact_person_phone:number;
    created_at:Date;
    Hospital_id:number;
    hos_organisation_id:number;
}
