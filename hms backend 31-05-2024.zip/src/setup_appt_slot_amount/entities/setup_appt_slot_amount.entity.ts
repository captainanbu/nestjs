export class SetupApptSlotAmount {
    id:number;
    staff_id:number;
    consult_duration:number;
    charge_id:number;
     hospital_doctor_global_shift_id:number;
    Hospital_id:number;
}
