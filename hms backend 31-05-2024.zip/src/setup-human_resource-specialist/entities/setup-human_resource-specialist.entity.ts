export class SetupHumanResourceSpecialist {
    id:number;
    specialist_name:string;
    is_active:string;
    created_at:Date;
    hospital_specialist_id:number;
    Hospital_id:number;
}
