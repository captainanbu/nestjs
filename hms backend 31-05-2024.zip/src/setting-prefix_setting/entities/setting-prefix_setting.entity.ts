export class SettingPrefixSetting {
    id:number;
    type:string;
    prefix:string;
    created_at:Date;
}
