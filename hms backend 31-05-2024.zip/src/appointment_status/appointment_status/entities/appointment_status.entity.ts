export class AppointmentStatus {
    id:number;
    status:string;
    create_time:any;
}
