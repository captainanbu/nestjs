import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection } from 'typeorm';
import { AppointmentStatus } from './entities/appointment_status.entity';

@Injectable()
export class AppointmentStatusService {
  constructor(@InjectConnection() private connection: Connection){}

  async create(AppointmentStatusEntity: AppointmentStatus) {
   
    const result = await this.connection.query('insert into appointment_status (status) values (?)',
    [AppointmentStatusEntity.status]
    )
 
    return  [{"data":{"id":result.insertId,
    "status":"success",
    "messege":"appointment_status details added successfully inserted",
    "inserted_data": await this.connection.query('SELECT * FROM appointment_status WHERE id = ?', [result.insertId])
    }}];  
 
  }

  async findAll() {
    const appointment_status = await this.connection.query(`select * from appointment_status`);
    return appointment_status;
  }

  async update(id:number,AppointmentStatusEntity:AppointmentStatus) {
    const result = await this.connection.query(
      `update appointment_status SET status = ? where id = ?`,
      [
        AppointmentStatusEntity.status,
        id
      ]
    )
    return  [{"data ":{
      status:"success",
      "messege":"appointment_status details updated successfully ",
      "updated_values":await this.connection.query('SELECT * FROM appointment_status WHERE id = ?', [id])
      }}];
  }

async remove(id:string) {
  const result = await this.connection.query(`delete from appointment_status where id = ?`, [id]);
  return [ {
    "status":"success",
    "message":"id: "+id+" deleted successfully"
  }]
}

}
