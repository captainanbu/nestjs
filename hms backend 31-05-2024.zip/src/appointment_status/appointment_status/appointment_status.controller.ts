import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { AppointmentStatusService } from './appointment_status.service';
import { AppointmentStatus } from './entities/appointment_status.entity';

@Controller('appointment-status')
export class AppointmentStatusController {
  constructor(private readonly appointmentStatusService: AppointmentStatusService) {}

  @Post()
  create(@Body()AppointmentStatusEntity:AppointmentStatus ) {
    return this.appointmentStatusService.create(AppointmentStatusEntity);
  }

  @Get()
  findAll() {
    return this.appointmentStatusService.findAll();
  }

 

  @Patch(':id')
  update(@Param('id') id: string, @Body() AppointmentStatusEntity:AppointmentStatus  ) {
    return this.appointmentStatusService.update(+id,AppointmentStatusEntity );
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.appointmentStatusService.remove(id);
  }
}
