export class SetupHospitalChargesChargeTypeMaster {
    id:number;
    charge_type:string;
    is_default:string;
    is_active:string;
    created_at:Date;
    hospital_charge_type_master_id:number;
    Hospital_id:number;
}