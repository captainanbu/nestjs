export class SetupBedBedStatus {}
