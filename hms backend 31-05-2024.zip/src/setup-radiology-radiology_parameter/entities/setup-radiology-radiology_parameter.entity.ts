export class SetupRadiologyRadiologyParameter {
    id:number;
    parameter_name:string;
    test_value:string;
    reference_range:string;
    gender:string;
    unit:string;
    description:string;
    created_at:Date;
    hospital_radiology_parameter_id:number;
    Hospital_id:number;
}
