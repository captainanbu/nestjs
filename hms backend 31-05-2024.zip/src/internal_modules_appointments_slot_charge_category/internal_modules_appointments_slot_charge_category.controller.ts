import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { InternalModulesAppointmentsSlotChargeCategoryService } from './internal_modules_appointments_slot_charge_category.service';

@Controller('internal-modules-appointments-slot-charge-category')
export class InternalModulesAppointmentsSlotChargeCategoryController {
  constructor(private readonly internalModulesAppointmentsSlotChargeCategoryService: InternalModulesAppointmentsSlotChargeCategoryService) {}


  @Get()
  findone() {
    return this.internalModulesAppointmentsSlotChargeCategoryService.findone();
  }


}
