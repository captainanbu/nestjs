/* eslint-disable prettier/prettier */
import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { DynamicDatabaseService } from 'src/dynamic_db.service';
import { Connection } from 'typeorm';
 
@Injectable()
export class InternalModulesAppointmentsSlotChargeCategoryService {
 
  constructor(@InjectConnection() private connection: Connection,
  @Inject(forwardRef(() => DynamicDatabaseService)) private dynamicDbService: DynamicDatabaseService
  ){}
 
  async findone() {
    const charge_category = await this.connection.query(`    select distinct charge_categories.name,charge_categories.id ,charge_type_module.module_shortcode
    from  charge_type_module join charge_categories on charge_categories.charge_type_id = charge_type_module.charge_type_master_id
    where charge_type_module.module_shortcode = "appointment"`)
    return charge_category;
  }
 
 
}