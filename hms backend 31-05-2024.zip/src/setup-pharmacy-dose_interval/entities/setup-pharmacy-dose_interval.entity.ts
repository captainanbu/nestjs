export class SetupPharmacyDoseInterval {
    id:number;
    name:string;
    created_at:Date;
    hospital_finding_category_id:number;
    Hospital_id:number;
}
