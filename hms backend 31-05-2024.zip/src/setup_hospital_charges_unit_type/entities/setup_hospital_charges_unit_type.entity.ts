export class SetupHospitalChargesUnitType {
    id:number;
    unit:number;
    is_active:string;
    created_at:Date;
    hospital_charge_units_id:number;
    Hospital_id:number;
}
