export class SetupHospitalChargesTaxCategory {
    id:number;
    name:string;
    percentage:string;
    created_at:Date;
    hospital_tax_category_id:number;
    Hospital_id:number;
}
