export class InternalAppointmentPriority {
    id:number;
    priority_status:string;
    created_at:Date;
    hospital_appoint_priority_id:number;
    Hospital_id:number;
}
