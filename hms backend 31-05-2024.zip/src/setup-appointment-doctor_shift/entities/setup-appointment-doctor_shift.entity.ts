export class SetupAppointmentDoctorShift {
    id:number;
    staff_id:string;
    global_shift_id:string;
    created_at:Date;
    hospital_doctor_global_shift_id:number;
    Hospital_id:number;
}
