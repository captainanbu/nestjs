export class SetupHospitalChargesChargeTypeModule {
    id:number;
    charge_type_master_id:number;
    module_shortcode:string;
    created_at:Date;
    hospital_charge_type_module_id:number;
    Hospital_id:number;
}
