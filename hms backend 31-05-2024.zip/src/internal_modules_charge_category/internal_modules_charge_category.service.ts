import { Injectable } from '@nestjs/common';
import { InternalModulesChargeCategory } from './entities/internal_modules_charge_category.entity';
import { Connection } from 'typeorm';
import { InjectConnection } from '@nestjs/typeorm';

@Injectable()
export class InternalModulesChargeCategoryService {
  constructor(@InjectConnection() private connection: Connection)
 {}
  async findall(charge_type_id:number) {
    const charge_category = await this.connection.query('select charge_categories.id, charge_categories.name from charge_categories where charge_categories.charge_type_id = ? ',[charge_type_id]);
    console.log(charge_category)
    
      return charge_category ;
   
}

}

