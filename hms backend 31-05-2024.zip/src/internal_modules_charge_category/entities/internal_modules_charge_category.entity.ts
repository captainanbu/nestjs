export class InternalModulesChargeCategory {}
