import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { InternalModulesChargeCategoryService } from './internal_modules_charge_category.service';

@Controller('internal-modules-charge-category')
export class InternalModulesChargeCategoryController {
  constructor(private readonly internalModulesChargeCategoryService: InternalModulesChargeCategoryService) {}

  @Get(':id')
  findOne(@Param('id') id:number) {
    return this.internalModulesChargeCategoryService.findall(id);
  }
}
