export class SetupSymptomsSymptomsType {
    id:number;
    symptoms_type:string;
    hospital_symptoms_id:number;
    Hospital_id:number;
}
