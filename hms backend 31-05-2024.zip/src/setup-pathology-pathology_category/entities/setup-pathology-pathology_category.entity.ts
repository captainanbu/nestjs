export class SetupPathologyPathologyCategory {
    id:number;
    category_name:string;
    created_at:Date;
    hospital_pathology_category_id:number;
    Hospital_id:number;
}
