export class SetupRadiologyRadiologyCategory {
    id:number;
    lab_name:string;
    created_at:Date;
    hospital_lab_id:number;
    Hospital_id:number;
}
