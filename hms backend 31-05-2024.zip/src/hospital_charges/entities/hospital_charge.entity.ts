export class HospitalCharge {
   hospital_id:number
   hospital_consulting_charge:string
   tax_percentage:string
   tax_amount:string

}
