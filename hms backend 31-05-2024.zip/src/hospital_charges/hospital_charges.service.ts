import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { DynamicDatabaseService } from 'src/dynamic_db.service';
import { Connection, createConnection } from 'typeorm';
import { HospitalCharge } from './entities/hospital_charge.entity';
import { MysqlConnectionOptions } from 'typeorm/driver/mysql/MysqlConnectionOptions';
 
 
@Injectable()
export class HospitalChargesService {
 
  constructor(@InjectConnection() private connection: Connection,
  @Inject(forwardRef(() => DynamicDatabaseService)) private dynamicDbService: DynamicDatabaseService
 
  ) {}
 
  async update(id: string,hos_chargesEntity: HospitalCharge) {
    let dynamicConnection;
    try {
      try {
        const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
   
          process.env.ADMIN_IP,
          process.env.ADMIN_DB_NAME,
          process.env.ADMIN_DB_PASSWORD,
          process.env.ADMIN_DB_USER_NAME
          )
         
        const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
         dynamicConnection = await createConnection(dynamicConnectionOptions)
      } catch (error) {
        return  error
      }
 
 
 
 
const check = await dynamicConnection.query(`select hospital_consulting_charge from hospitals where plenome_id = ?`,[hos_chargesEntity.hospital_id])
 
 
if(check) {
  if((hos_chargesEntity.hospital_consulting_charge || hos_chargesEntity.tax_percentage || hos_chargesEntity.tax_amount) == ""){
 
    if(dynamicConnection){
      dynamicConnection.close()
    }
   
    return{
      "status":"failed",
      "message":"enter all the necessary values to update",
    }
   
  }
  else{
    const AdminUpdate = await dynamicConnection.query(`
    update hospitals set
    hospital_consulting_charge = ?,
    tax_percentage = ?,
    tax_amount = ?
    where plenome_id = ?`, [
     
      hos_chargesEntity.hospital_consulting_charge,
      hos_chargesEntity.tax_percentage,
      hos_chargesEntity.tax_amount,
      hos_chargesEntity.hospital_id
    ])
   
    console.log(AdminUpdate,"AdminUpdate");
    if(dynamicConnection){
      dynamicConnection.close()
    }
   
    return{
      "status":"success",
      "message":"hospitals details updated successfully",
    }
    }
 
}
else
{
  if(dynamicConnection){
    dynamicConnection.close()
  }
  return{
    "status":"failed",
    "message":"Enter correct hospital_id to set charges",
  }
}
 
    }
 
  catch (error) {
    if(dynamicConnection){
      dynamicConnection.close()
    }
    return error
}
}
 
 
async findall(plenome_id:string) {
 
  const dynamicDbConfig = this.dynamicDbService.createDynamicDatabaseConfig(
   
    process.env.ADMIN_IP,
    process.env.ADMIN_DB_NAME,
    process.env.ADMIN_DB_PASSWORD,
    process.env.ADMIN_DB_USER_NAME
    )
   
  const dynamicConnectionOptions: MysqlConnectionOptions = dynamicDbConfig as MysqlConnectionOptions;
   const dynamicConnection = await createConnection(dynamicConnectionOptions)
 
  const hospital = await dynamicConnection.query(`   SELECT
  hospitals .plenome_id,
  hospitals.hospital_name,
 hospitals.hospital_consulting_charge,
 hospitals.tax_percentage,
 hospitals.tax_amount,
    concat((hospitals.hospital_consulting_charge + (hospitals.hospital_consulting_charge * (hospitals.tax_percentage/100)))) as amount
FROM
   hospitals
WHERE
plenome_id = 1;`,[plenome_id]
)
 
  if(dynamicConnection){
    dynamicConnection.close()
  }
  return hospital;
}
 
 
 
 
 
}