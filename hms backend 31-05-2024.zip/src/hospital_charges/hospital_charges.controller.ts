import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { HospitalChargesService } from './hospital_charges.service';
import { HospitalCharge } from './entities/hospital_charge.entity';

@Controller('hospital-charges')
export class HospitalChargesController {
  constructor(private readonly hospitalChargesService: HospitalChargesService) {}

  @Patch(':id') 
   update(@Param('id') id: string, @Body() hos_chargesEntity: HospitalCharge) {
    console.log("entering controller");

    return  this.hospitalChargesService.update(id,hos_chargesEntity);
    
  }

  @Get('/hos_amount/:plenome_id')
  findall(@Param('plenome_id') plenome_id:string) {
    return this.hospitalChargesService.findall(plenome_id);
  }

  // @Get()
  // findall(
  //     @Query('hospital_consulting_charge') hospital_consulting_charge: number,
  //     @Query('tax_percentage') tax_percentage: string,
  //     @Query('tax_amount') tax_amount: string,
  //     @Query('plenome_id') plenome_id: string,
  // ) {
  //     return this.hospitalChargesService.findall(hospital_consulting_charge, tax_percentage, tax_amount, plenome_id);
  // }
  
 
}
