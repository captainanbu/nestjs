export class FindingsCategory {
    id:number;
    category:string;
    created_at:Date;
    hospital_finding_category_id:number;
    Hospital_id:number;
}


