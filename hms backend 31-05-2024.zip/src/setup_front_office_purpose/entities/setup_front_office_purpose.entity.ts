export class SetupFrontOfficePurpose {
    id:number;
    visitors_purpose:string;
    description:string;
    created_at:Date;
    hospital_visitors_purpose_id:number;
    Hospital_id:number;
}
