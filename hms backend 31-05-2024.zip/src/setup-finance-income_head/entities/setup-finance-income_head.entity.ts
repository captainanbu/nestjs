export class SetupFinanceIncomeHead {
    id:number;
    income_category:string;
    description:Text;
    is_active:string;
    is_deleted:string;
    created_at:Date;
    hospital_income_head_id:number;
    Hospital_id:number;
}
