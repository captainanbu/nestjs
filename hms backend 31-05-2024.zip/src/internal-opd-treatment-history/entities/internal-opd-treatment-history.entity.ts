export class InternalOpdTreatmentHistory {}
