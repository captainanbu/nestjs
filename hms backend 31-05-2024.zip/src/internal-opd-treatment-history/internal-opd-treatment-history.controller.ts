/* eslint-disable prettier/prettier */
import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { InternalOpdTreatmentHistoryService } from './internal-opd-treatment-history.service';

@Controller('internal-opd-treatment-history')
export class InternalOpdTreatmentHistoryController {
  constructor(private readonly internalOpdTreatmentHistoryService: InternalOpdTreatmentHistoryService) {}

  @Get()
  findAll(@Query('patient_id') patient_id:number,@Query('opd_details_discharged') opd_details_discharged:number) {
    return this.internalOpdTreatmentHistoryService.findAll(patient_id,opd_details_discharged);
  }

  @Get()
  findOne(@Query('patient_id') patient_id:number,@Query('opd_details_id')opd_details_id:number) {
    return this.internalOpdTreatmentHistoryService.findOne(patient_id,opd_details_id);
  }

}
