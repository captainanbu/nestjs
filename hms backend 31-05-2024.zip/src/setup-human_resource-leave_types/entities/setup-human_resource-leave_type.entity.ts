export class SetupHumanResourceLeaveType {
    id:number;
    type:string;
    is_active:string;
    created_at:Date;
    hospital_leave_types_id:number;
    Hospital_id:number;
}
