export class SettingsUsersStaff {
    id:number;
    is_active:string;
}
