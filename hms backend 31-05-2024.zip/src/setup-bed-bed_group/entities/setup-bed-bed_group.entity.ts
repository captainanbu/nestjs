export class SetupBedBedGroup {
    id:number;
    name:string;
    color:string;
    description:string;
    floor:string;
    is_active:string;
    created_at:string;
    hospital_bed_group_id:number;
    Hospital_id:number;
}
