export class InternalOpdOverviewConsultantDoctor {}
