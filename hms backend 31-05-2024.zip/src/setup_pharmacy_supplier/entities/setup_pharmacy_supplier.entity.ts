export class SetupPharmacySupplier {
    id:number;
    supplier:string;
    contact:number;
    supplier_person:string;
    supplier_person_contact:number;
    supplier_drug_licence:string;
    address:string;
    created_at:Date;
    hospital_medicine_supplier_id:string;
    Hospital_id:string;
}
