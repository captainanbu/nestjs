export class SetupInventoryItemStore {
    id:number;
    item_store:string;
    code:string;
    description:string;
    created_at:Date;
    hospital_item_store_id:number;
    Hospital_id:number;
}
